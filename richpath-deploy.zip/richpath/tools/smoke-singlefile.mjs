/**
 * Runtime smoke test for the single-file build (richpath-demo.html).
 * With no arguments it finds the file itself; pass a path to test another copy.
 * Run:  npm i -D jsdom && node tools/smoke-singlefile.mjs
 * Loads the file in jsdom, drives the real flows through the embedded API,
 * and renders every view to catch template/scope errors.
 */
import fs from 'node:fs';
import { JSDOM } from 'jsdom';

/**
 * Locate the single-file build. It sits one level above the repository in the
 * development layout, and inside `standalone/` in the packaged deployment
 * archive — the same checks must pass from either.
 */
function findDemoFile() {
  const candidates = [
    new URL('../../richpath-demo.html', import.meta.url),
    new URL('../standalone/richpath-demo.html', import.meta.url),   // deployment archive
    new URL('./richpath-demo.html', import.meta.url),
  ];
  for (const url of candidates) {
    if (fs.existsSync(url)) return url;
  }
  throw new Error(
    'richpath-demo.html not found. Looked in:\n  ' +
      candidates.map((u) => u.pathname).join('\n  '),
  );
}

const demoFile = findDemoFile();
const html = fs.readFileSync(demoFile, 'utf8');
const errors = [];
const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://demo.local/', pretendToBeVisual: true });
const { window } = dom;
window.addEventListener('error', (e) => errors.push('window error: ' + e.message));

const results = [];
const check = (name, fn) => {
  try { fn(); results.push('  ✓ ' + name); }
  catch (err) { results.push('  ✗ ' + name + ' — ' + err.message); }
};
const evalIn = (code) => window.eval(code);
const text = () => window.document.getElementById('app').textContent || '';
const htmlOfApp = () => window.document.getElementById('app').innerHTML || '';
const assert = (cond, msg) => { if (!cond) throw new Error(msg || 'assertion failed'); };
const renderAt = (hash) => { window.location.hash = hash; evalIn('render()'); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

await wait(300);

/* ---------------------------------------------------------------- landing */
check('landing renders hero, ticker, reviews and FAQ', () => {
  const body = htmlOfApp();
  assert(body.includes('Do tasks, watch videos'), 'hero missing');
  assert(body.includes('Recent cash-outs'), 'ticker card missing');
  assert(body.includes('Marisol'), 'reviews missing');
  assert(body.includes('Frequently asked questions'), 'FAQ missing');
  assert(text().includes('Sample data'), 'demo badge missing');
});

check('language switcher applies Spanish and Arabic RTL', () => {
  evalIn("setLang('es')");
  assert(text().includes('Cómo funciona') || htmlOfApp().includes('Cómo funciona'), 'Spanish not applied');
  evalIn("setLang('ar')");
  assert(window.document.documentElement.getAttribute('dir') === 'rtl', 'dir not rtl for Arabic');
  evalIn("setLang('en')");
  assert(window.document.documentElement.getAttribute('dir') === 'ltr', 'dir not restored');
});

/* ------------------------------------------------------------------- auth */
check('protected route redirects anonymous visitors to sign-in', () => {
  window.location.hash = '#/withdraw';
  evalIn('render()');
  assert(window.location.hash.startsWith('#/login'), 'no redirect to login, got ' + window.location.hash);
});

check('registration validates password strength', () => {
  let threw = false;
  try { evalIn("API.register({name:'Weak',email:'w@example.com',password:'short',acceptTerms:true})"); }
  catch (e) { threw = true; assert(/8\+/.test(e.message), 'unexpected message: ' + e.message); }
  assert(threw, 'weak password was accepted');
});

check('registration requires terms acceptance', () => {
  let threw = false;
  try { evalIn("API.register({name:'No Terms',email:'n@example.com',password:'passw0rd!',acceptTerms:false})"); }
  catch (e) { threw = true; }
  assert(threw, 'registration without terms accepted');
});

let inviteCode = null;
check('registration credits a welcome bonus and issues an invite code', () => {
  const u = evalIn("API.register({name:'Demo Reviewer',email:'demo@example.com',password:'passw0rd!',acceptTerms:true,locale:'en'})");
  assert(u.balance === 0.3, 'welcome bonus expected 0.30, got ' + u.balance);
  assert(u.referralCode && u.referralCode.length === 8, 'invite code missing');
  inviteCode = u.referralCode;
});

check('duplicate email is rejected', () => {
  let threw = false;
  try { evalIn("API.register({name:'Copy',email:'demo@example.com',password:'passw0rd!',acceptTerms:true})"); }
  catch (e) { threw = true; assert(/already exists/i.test(e.message), 'wrong error: ' + e.message); }
  assert(threw, 'duplicate email accepted');
});

check('wrong password is rejected with a generic message', () => {
  let threw = false;
  try { evalIn("API.login('demo@example.com','nope')"); }
  catch (e) { threw = true; assert(e.message === 'Email or password is incorrect', e.message); }
  assert(threw, 'bad login accepted');
});

/* -------------------------------------------------------------- dashboard */
check('dashboard renders balance, stats and next step', () => {
  renderAt('#/user');
  assert(text().includes('Withdrawable'), 'balance block missing');
  assert(text().includes('Next step to cash out'), 'next-step card missing');
});

check('ledger contains the welcome credit with a running balance', () => {
  const led = evalIn("API.ledger(1)");
  assert(led.items.some((r) => r.type === 'welcome' && r.amount === 0.3), 'welcome row missing');
  assert(led.items[0].balanceAfter === 0.3, 'balance_after wrong: ' + led.items[0].balanceAfter);
});

/* ------------------------------------------------------------------ tasks */
check('task centre lists 10 offers with rewards', () => {
  renderAt('#/task');
  const list = evalIn('API.tasks()');
  assert(list.length === 10, 'expected 10 tasks, got ' + list.length);
  assert(list.every((t) => t.reward > 0), 'a task has no reward');
  assert(text().includes('Dragon Merge Saga'), 'task row missing');
});

check('task category filter works', () => {
  const surveys = evalIn("API.tasks().filter(t=>t.category==='survey')");
  assert(surveys.length === 3, 'expected 3 surveys, got ' + surveys.length);
});

let completionId = null;
check('starting a task opens a completion and a 20s engagement window', () => {
  const started = evalIn("API.startTask('dragon-merge-saga')");
  assert(started.minEngagementSeconds === 20, 'engagement window wrong');
  completionId = started.completionId;
});

check('completing before the window is rejected server-side', () => {
  let threw = false;
  try { evalIn(`API.completeTask(${JSON.stringify(completionId)})`); }
  catch (e) { threw = true; assert(/not completed|at least 20 seconds/.test(e.message), e.message); }
  assert(threw, 'early completion was credited');
});

check('completing after the window credits the reward', () => {
  // Backdate the start to simulate elapsed time (the timer itself is UI-only).
  evalIn(`DB.completions.find(c=>c.id===${JSON.stringify(completionId)}).startedAt = new Date(Date.now()-25000).toISOString()`);
  const res = evalIn(`API.completeTask(${JSON.stringify(completionId)})`);
  assert(res.status === 'credited', 'status not credited');
  assert(res.reward === 1.2, 'reward expected 1.20, got ' + res.reward);
  assert(res.balance === 1.5, 'balance expected 1.50, got ' + res.balance);
});

check('the same task cannot be credited twice', () => {
  let threw = false;
  try { evalIn(`API.completeTask(${JSON.stringify(completionId)})`); }
  catch (e) { threw = true; assert(/already credited/.test(e.message), e.message); }
  assert(threw, 'double credit allowed');
});

check('a 24h cooldown is applied after crediting', () => {
  const t = evalIn("API.tasks().find(x=>x.id==='dragon-merge-saga')");
  assert(t.cooldownEndsAt && new Date(t.cooldownEndsAt) > new Date(), 'no cooldown set');
  let threw = false;
  try { evalIn("API.startTask('dragon-merge-saga')"); } catch (e) { threw = true; }
  assert(threw, 'started a task still on cooldown');
});

/* ----------------------------------------------------------------- videos */
check('video centre hides bonus videos until 3 tasks are done', () => {
  evalIn("API.setVideoSource({ mode:'sim' })");   // offline source for deterministic tests
  renderAt('#/video');
  const s = evalIn('API.videos()');
  assert(s.dailyLimit === 10, 'base limit should be 10');
  assert(s.bonusUnlocked === false, 'bonus should be locked after 1 task');
  assert(s.remainingTasksForBonus === 2, 'expected 2 tasks remaining');
});

check('completing a video credits the user; a second view is blocked', () => {
  const first = evalIn("API.completeVideo('sim:v1', 30)");
  assert(first.reward === 0.05, 'video reward expected 0.05, got ' + first.reward);
  let threw = false;
  try { evalIn("API.completeVideo('sim:v1', 30)"); } catch (e) { threw = true; assert(/Already watched/.test(e.message), e.message); }
  assert(threw, 'duplicate view allowed');
});

check('under-watching is rejected by the watch-time rule', () => {
  let threw = false;
  try { evalIn("API.completeVideo('sim:v2', 5)"); }
  catch (e) { threw = true; assert(/Keep watching/.test(e.message), e.message); }
  assert(threw, 'a 5-second view was credited');
});

check('the video daily cap is enforced', () => {
  evalIn("for (const v of DB.videos.slice(1,11)) { try { API.completeVideo('sim:'+v.id, 30) } catch(e){} }");
  let threw = false;
  try { evalIn("API.completeVideo('sim:v1', 30)"); } catch (e) { threw = true; assert(/limit|Already/.test(e.message), e.message); }
  const s = evalIn('API.videos()');
  assert(s.watchedToday === 10, 'expected 10 watched, got ' + s.watchedToday);
  assert(threw, 'exceeded the daily cap');
});

/* ------------------------------------------------------ youtube integration */
check('the default source is the built-in YouTube pool', () => {
  evalIn("API.setVideoSource({ mode:'pool' })");
  const s = evalIn('API.videos()');
  assert(s.mode === 'pool', 'default mode is not pool, got ' + s.mode);
  assert(s.videos.length === 10, 'expected 10 slots, got ' + s.videos.length);
  assert(s.videos.every((v) => /^[A-Za-z0-9_-]{11}$/.test(v.videoId)), 'a slot has no usable YouTube id');
  assert(s.videos.every((v) => v.id === 'yt:' + v.videoId), 'slot keys are not derived from the YouTube id');
  assert(new Set(s.videos.map((v) => v.videoId)).size === 10, 'duplicate videos in the daily list');
});

check('daily draw is stable within the day but covers the pool', () => {
  const a = evalIn('API.videos().videos.map(v=>v.videoId)').join(',');
  evalIn('render()');
  const b = evalIn('API.videos().videos.map(v=>v.videoId)').join(',');
  assert(a === b, 'the list reshuffled mid-session');
  assert(evalIn('YT_POOL.length') === 11, 'pool size changed');
});

check('the watch-time rule matches each video length (20s cap, 90% floor)', () => {
  assert(evalIn('requiredPlayback(1761)') === 20, 'long video should need 20s');
  assert(evalIn('requiredPlayback(19)') === 18, 'the 19s video should need 18s');
  assert(evalIn('requiredPlayback(0)') === 20, 'unknown duration should fall back to 20s');
});

check('reward is refused below the per-video threshold and allowed at it', () => {
  evalIn("DB.views = DB.views.filter(v => v.date !== today())");   // clear today's cap for this check
  const short = evalIn("YT_POOL.find(v => v.seconds === 19).id");            // 'Me at the zoo'
  // Force that video into today's list by using it as a custom source.
  evalIn(`API.setVideoSource({ mode:'custom', customIds:[{ id:${JSON.stringify(short)}, title:'Me at the zoo', seconds:19 }] })`);
  const slot = evalIn('API.videos()').videos[0];
  assert(slot.requiredSeconds === 18, 'expected 18s required, got ' + slot.requiredSeconds);

  let threw = false;
  try { evalIn(`API.completeVideo(${JSON.stringify(slot.id)}, 17)`); }
  catch (e) { threw = true; assert(/Keep watching/.test(e.message), e.message); }
  assert(threw, 'credited 17s on a video that needs 18s');

  const res = evalIn(`API.completeVideo(${JSON.stringify(slot.id)}, 18)`);
  assert(res.reward === 0.05, 'reward wrong: ' + res.reward);
});

check('a video blocked for embedding is dropped from rotation', () => {
  evalIn("API.setVideoSource({ mode:'pool', blocked:[] })");
  const first = evalIn('API.videos()').videos[0].videoId;
  evalIn(`API.blockVideo(${JSON.stringify(first)}, 'owner does not allow embedding')`);
  const after = evalIn('API.videos()').videos.map((v) => v.videoId);
  assert(!after.includes(first), 'blocked video still offered');
  assert(after.length === 10, 'list should refill from the pool, got ' + after.length);
  assert(evalIn('DB.videoSource.blocked.length') === 1, 'block list not persisted');

  evalIn('API.unblockAll()');
  assert(evalIn('DB.videoSource.blocked.length') === 0, 'unblock did not clear');
});

check('every video in the built-in pool is excluded from live streams and has a duration', () => {
  const bad = evalIn("YT_POOL.filter(v => !(v.seconds > 0) || v.id === '21X5lGlDOfg')");
  assert(bad.length === 0, 'pool contains a stream without a duration: ' + JSON.stringify(bad));
  assert(new Set(evalIn('YT_POOL.map(v=>v.id)')).size === evalIn('YT_POOL.length'), 'duplicate ids in pool');
});

check('YouTube URL shapes are parsed (watch, youtu.be, embed, shorts, raw id)', () => {
  const parsed = evalIn("parseYouTubeIds('https://www.youtube.com/watch?v=aqz-KE-bpKQ https://youtu.be/jNQXAC9IVRw https://www.youtube.com/embed/eRsGyueVLvQ https://www.youtube.com/shorts/WhWc3b3KhnY sNhhvQGsMEc not a video')");
  assert(parsed.length === 5, 'parsed ' + parsed.length + ' instead of 5: ' + parsed.join(','));
  assert(parsed.includes('aqz-KE-bpKQ') && parsed.includes('jNQXAC9IVRw') && parsed.includes('sNhhvQGsMEc'), 'missing ids');
  assert(!parsed.some((x) => x.length !== 11), 'emitted a non-11-char id');
});

check('ISO-8601 durations from the Data API convert correctly', () => {
  assert(evalIn("isoDurationToSeconds('PT19S')") === 19, 'PT19S');
  assert(evalIn("isoDurationToSeconds('PT10M35S')") === 635, 'PT10M35S');
  assert(evalIn("isoDurationToSeconds('PT29M21S')") === 1761, 'PT29M21S');
  assert(evalIn("isoDurationToSeconds('PT1H2M3S')") === 3723, 'PT1H2M3S');
  assert(evalIn("isoDurationToSeconds('garbage')") === 0, 'garbage');
});

check('the Data API path refuses to run without a key and states why', () => {
  evalIn("API.setVideoSource({ mode:'api', apiKey:'' })");
  const res = evalIn('API.fetchRandomFromApi()');
  assert(typeof res.then === 'function', 'should return a promise');
});

check('the video page renders thumbnails, durations and the source control', () => {
  evalIn("API.setVideoSource({ mode:'pool', blocked:[] })");
  renderAt('#/video');
  const body = htmlOfApp();
  assert(body.includes('i.ytimg.com/vi/'), 'no YouTube thumbnails rendered');
  assert(body.includes('Video source'), 'source control missing');
  assert(body.includes('Built-in pool'), 'source label missing');
  assert(body.includes('Watch'), 'watch buttons missing');
  assert(/needs 20s/.test(text()), 'per-video threshold not shown to the user');
  assert(body.includes('youtube-nocookie.com'), 'privacy note missing');
});

check('the source picker exposes all four modes', () => {
  evalIn('videoSourceModal()');
  const modal = window.document.querySelector('.modal');
  assert(modal, 'modal did not open');
  const body = modal.innerHTML;
  for (const label of ['Built-in pool', 'YouTube API', 'Your own list', 'Simulated player']) {
    assert(body.includes(label), 'missing source option: ' + label);
  }
  assert(body.includes('API key'), 'key field missing from the API option');
  evalIn('closeModal()');
});

check('a dead player offers the offline fallback and says why', () => {
  assert(typeof window.ytUnavailable === 'function', 'fallback helper missing');
  // Simulate the sandboxed-preview path: player never loads.
  evalIn("API.setVideoSource({ mode:'pool' }); render(); watchVideo(API.videos().videos[0].id)");
  evalIn('ytUnavailable({ id:"yt:x", videoId:"aqz-KE-bpKQ", title:"T", reward:0.05, requiredSeconds:20 }, 20)');
  const modal = window.document.querySelector('.modal').innerHTML;
  assert(/can’t load here|can't load here/.test(modal), 'no explanation shown');
  assert(modal.includes('Use simulated player'), 'no offline fallback offered');
  evalIn('closeModal()');
});

check('player errors are translated and block-listed for embed refusals', () => {
  evalIn("API.setVideoSource({ mode:'pool', blocked:[] }); render();");
  const before = evalIn("DB.videoSource.blocked.length");
  const slot = evalIn('API.videos().videos[0]');
  evalIn('watchVideo(' + JSON.stringify(slot.id) + ')');
  assert(window.document.querySelector('.modal'), 'player modal did not open');
  evalIn('onPlayerError(150, ' + JSON.stringify(slot) + ')');
  const after = evalIn("DB.videoSource.blocked.length");
  assert(after === before + 1, 'error 150 was not block-listed');
  const modal = window.document.querySelector('.modal').innerHTML;
  assert(/does not allow this video to be embedded/.test(modal), 'error text not shown in plain language');
  evalIn('closeModal(); API.unblockAll(); API.setVideoSource({ mode:"sim" })');
});

/* ------------------------------------------------------------------ daily */
check('daily bonus can only be claimed once per day', () => {
  const first = evalIn('API.claimDaily()');
  assert(first.reward === 0.05, 'day-1 bonus expected 0.05, got ' + first.reward);
  assert(first.streak === 1, 'streak should be 1');
  let threw = false;
  try { evalIn('API.claimDaily()'); } catch (e) { threw = true; assert(/already claimed/.test(e.message), e.message); }
  assert(threw, 'double daily claim allowed');
});

check('the streak schedule escalates across seven days', () => {
  const s = evalIn('API.dailyState()');
  assert(s.schedule.length === 7, 'expected a 7-day schedule');
  assert(s.schedule[6].reward > s.schedule[0].reward, 'day 7 should beat day 1');
});

/* -------------------------------------------------------------- referrals */
check('an invited signup pays the inviter and masks the invitee name', () => {
  const before = evalIn("DB.users.find(u=>u.email==='demo@example.com').balanceCents");
  evalIn(`API.logout(); API.register({name:'Invited Friend',email:'friend@example.com',password:'passw0rd!',referralCode:${JSON.stringify(inviteCode)},acceptTerms:true})`);
  evalIn("API.logout(); API.login('demo@example.com','passw0rd!')");
  const after = evalIn("DB.users.find(u=>u.email==='demo@example.com').balanceCents");
  assert(after - before === 25, 'signup reward expected 25c, got ' + (after - before));

  const s = evalIn('API.referrals()');
  assert(s.referralCount === 1, 'referral not linked');
  assert(s.referrals[0].maskedName.includes('*'), 'invitee name not masked');
  assert(s.referrals[0].maskedName !== 'Invited Friend', 'raw name leaked');
});

check('referral earnings include a 10% share of invitee income', () => {
  const share = Math.floor(90 * 0.10); // invitee completed puzzle-kingdom ($0.90)
  evalIn("API.logout(); API.login('friend@example.com','passw0rd!'); const st = API.startTask('puzzle-kingdom'); DB.completions.find(c=>c.id===st.completionId).startedAt = new Date(Date.now()-25000).toISOString(); API.completeTask(st.completionId);");
  evalIn("API.logout(); API.login('demo@example.com','passw0rd!')");
  const led = evalIn('API.ledger(1)');
  const shareRow = led.items.find((r) => r.type === 'referral' && r.amount === share / 100);
  assert(shareRow, 'no 10% share row of ' + (share / 100));
});

check('referral page renders milestones and requires 3 active friends to claim', () => {
  renderAt('#/partners');
  const s = evalIn('API.referrals()');
  assert(s.milestones.length === 4, 'milestones missing');
  assert(s.dailyRewardAvailable === false, 'daily reward should be locked below 3 active friends');
  assert(text().includes('Your referrals'), 'referral list missing');
  assert(text().includes('pyramid scheme'), 'compliance notice missing from the invite page');
});

/* --------------------------------------------------------------- cash out */
check('cash-out is blocked before the checklist is met', () => {
  const e = evalIn('API.eligibility()');
  assert(e.eligible === false, 'should not be eligible yet');
  assert(e.reasons.some((r) => r.code === 'no_payment_method'), 'payment-method reason missing');
  assert(e.reasons.some((r) => r.code === 'not_enough_tasks'), 'task reason missing');
  let threw = false;
  try { evalIn('API.createWithdrawal(5, "bank")'); } catch (err) { threw = true; assert(/not eligible/.test(err.message), err.message); }
  assert(threw, 'withdrawal allowed while ineligible');
});

check('payout destination is validated and stored masked only', () => {
  let threw = false;
  try { evalIn("API.savePaymentMethod('usdt','Demo Reviewer','abc')"); } catch (e) { threw = true; }
  assert(threw, 'short destination accepted');

  const items = evalIn("API.savePaymentMethod('usdt','Demo Reviewer','TQ5d8Xk2pQ9rLm4Nv7Wc3Zb6Yh1Js8Ue2G')");
  assert(items[0].destinationMasked === '****Ue2G', 'masking wrong: ' + items[0].destinationMasked);
  const raw = JSON.stringify(items);
  assert(!raw.includes('TQ5d8Xk2pQ9rLm4Nv7Wc3Zb6Yh1Js8Ue2G'), 'raw destination leaked');
});

check('account holder name is required', () => {
  let threw = false;
  try { evalIn("API.savePaymentMethod('bank','','1234567890')"); } catch (e) { threw = true; }
  assert(threw, 'empty account name accepted');
});

check('cash-out is blocked until the 3-task minimum is met', () => {
  evalIn("API.demoTopUp(); API.demoTopUp(); API.demoTopUp();");
  const e = evalIn('API.eligibility()');
  assert(e.creditedTasks === 1, 'expected 1 credited task so far, got ' + e.creditedTasks);
  assert(e.reasons.some((r) => r.code === 'not_enough_tasks'), 'task gate not enforced');
  // Two more tasks, backdated so the engagement window has elapsed.
  evalIn(`for (const taskId of ['word-voyage','bubble-blast-quest']) {
    const st = API.startTask(taskId);
    DB.completions.find(c => c.id === st.completionId).startedAt = new Date(Date.now() - 25000).toISOString();
    API.completeTask(st.completionId);
  }`);
  const mid = evalIn('API.eligibility()');
  assert(mid.creditedTasks === 3, 'expected 3 credited tasks, got ' + mid.creditedTasks);
});

check('once the checklist clears a cash-out succeeds and holds funds', () => {
  const e = evalIn('API.eligibility()');
  assert(e.creditedTasks === 3, 'expected 3 credited tasks');
  assert(e.eligible === true, 'should be eligible: ' + JSON.stringify(e.reasons));

  const before = evalIn("DB.users.find(u=>u.email==='demo@example.com').balanceCents");
  const w = evalIn("API.createWithdrawal(10, 'usdt')");
  assert(w.amount === 10, 'amount wrong');
  const after = evalIn("DB.users.find(u=>u.email==='demo@example.com').balanceCents");
  assert(before - after === 1000, 'funds not held: ' + (before - after));
});

check('a second cash-out is refused while one is pending', () => {
  let threw = false;
  try { evalIn("API.createWithdrawal(10, 'usdt')"); } catch (e) { threw = true; assert(/already have a cash-out/.test(e.message), e.message); }
  assert(threw, 'concurrent cash-out allowed');
});

check('the minimum cash-out amount is enforced', () => {
  evalIn("DB.withdrawals.filter(w=>w.userId===DB.session).forEach(w=>w.status='failed')");
  let threw = false;
  try { evalIn("API.createWithdrawal(1, 'usdt')"); } catch (e) { threw = true; assert(/minimum cash-out/.test(e.message), e.message); }
  assert(threw, 'below-minimum cash-out allowed');
});

/* ---------------------------------------------------------------- records */
check('records page renders both the earnings and payment logs', () => {
  renderAt('#/record');
  assert(text().includes('Earnings log'), 'ledger tab missing');
  assert(/Task reward|Demo top-up|Video reward/.test(text()), 'ledger rows missing');
  evalIn("recTab='payments'; render()");
  assert(text().includes('Payment log'), 'payments tab missing');
  assert(text().includes('$10.00'), 'withdrawal row missing');
  evalIn("recTab='ledger'; render()");
});

check('ledger pagination works', () => {
  const p1 = evalIn('API.ledger(1)');
  assert(p1.pageSize === 12, 'page size wrong');
  assert(p1.items.length <= 12, 'page too large');
});

/* ------------------------------------------------------------- all views */
check('the FAQ ships the best questions with substantive, non-promissory answers', () => {
  const faq = evalIn('FAQ');
  assert(faq.length >= 5, 'expected at least 5 questions, got ' + faq.length);

  for (const item of faq) {
    assert(typeof item.q === 'string' && item.q.endsWith('?'), 'question not phrased as a question: ' + item.q);
    assert(item.q.length > 15, 'question too thin: ' + item.q);
    assert(typeof item.a === 'string' && item.a.length >= 120, 'answer too thin (' + item.a.length + ' chars): ' + item.q);
    assert(!/\{\{|\bundefined\b|\$\{/.test(item.a), 'answer has an unresolved template value: ' + item.q);
    assert(!/guaranteed|risk[- ]free|get rich|earn up to|\$\d+ (per|a) day/i.test(item.a), 'income promise in: ' + item.q);
  }

  // The answers a trust-focused FAQ has to contain.
  const all = faq.map((f) => f.q + ' ' + f.a).join(' ');
  assert(/pyramid/.test(all), 'no answer warns about recruitment-gated withdrawal / pyramid schemes');
  assert(/never removes money|never removes money you already earned|does not remove money/i.test(all), 'no reassurance about balances after a reversed offer');
  assert(/password/.test(all) && /one-time code/.test(all), 'no anti-phishing guidance');
  assert(/VPN/.test(all), 'no VPN / multi-account rule');
  assert(all.includes(evalIn('CFG.supportEmail')), 'the contact answer does not name the support address');

  // No unsafe claims about this build: it must be honest that nothing is real.
  assert(/no real money|not.*real money|demonstration/i.test(all), 'the FAQ does not disclose that this build pays nothing');
});

check('the landing page shows the six best questions and links to the rest', () => {
  renderAt('#/');
  const sections = window.document.querySelectorAll('details.faq');
  assert(sections.length === 6, 'expected 6 FAQ entries on the landing page, got ' + sections.length);
  assert(text().includes('Read all'), 'no link to the full FAQ list');
  assert(text().includes(String(evalIn('FAQ.length'))), 'the link does not state how many questions there are');
  assert(!text().includes(evalIn('FAQ[10].q')), 'a non-landing question leaked onto the landing page');
  // The bug that hid this section before: entries rendered with empty summaries.
  for (const node of sections) {
    assert(node.querySelector('summary').textContent.trim().length > 10, 'an FAQ summary rendered empty');
    assert(node.querySelector('p').textContent.trim().length > 100, 'an FAQ answer rendered empty');
  }
  assert(htmlOfApp().includes('#/faq') || htmlOfApp().includes('faq'), 'no route link to the FAQ page');
});

check('the FAQ page shows every question', () => {
  renderAt('#/faq');
  const sections = window.document.querySelectorAll('details.faq');
  const expected = evalIn('FAQ.length');
  assert(sections.length === expected, 'FAQ page shows ' + sections.length + ' of ' + expected);
  assert(text().includes(evalIn('FAQ[10].q')), 'the last question is missing from the FAQ page');
});

check('the support address is the configured one everywhere it appears', () => {
  const expected = evalIn('CFG.supportEmail');
  assert(/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(expected), 'not a usable address: ' + expected);

  renderAt('#/contact');
  assert(text().includes(expected), 'contact page does not show ' + expected);
  assert(htmlOfApp().includes('mailto:' + expected), 'contact page has no mailto link');

  renderAt('#/');
  assert(htmlOfApp().includes('mailto:' + expected), 'footer has no mailto link');
  assert(text().includes(expected), 'footer does not show the address');

  renderAt('#/faq');
  assert(text().includes(expected), 'FAQ does not point at the support address');
});

check('every route renders without throwing', () => {
  for (const hash of ['#/', '#/user', '#/task', '#/video', '#/daily', '#/partners', '#/withdraw',
                      '#/record', '#/faq', '#/about', '#/privacy', '#/contact', '#/notes', '#/nope']) {
    window.location.hash = hash;
    evalIn('render()');
    assert(htmlOfApp().length > 100, 'view ' + hash + ' rendered nothing');
  }
});

check('build notes page carries the docs, the compliance list and a reset control', () => {
  renderAt('#/notes');
  const body = htmlOfApp();
  for (const needle of ['Build notes', 'What the reference site is', 'Technology recommendation',
                        'Database &amp; API', 'Deliberately NOT reproduced', 'pyramid', 'Where the real code lives']) {
    assert(body.includes(needle), 'missing section: ' + needle);
  }
});

check('modals expose an escape hatch (closeModal is global)', () => {
  assert(typeof window.closeModal === 'function', 'closeModal not global — inline X buttons would break');
  assert(typeof window.go === 'function', 'go() not global — inline links would break');
});

check('reset restores a clean demo state', () => {
  evalIn('reset()');
  const s = evalIn('API.stats()');
  assert(s.registeredUsers === 0, 'reset left users behind');
  assert(evalIn('DB.tasks.length') === 10, 'tasks lost after reset');
  assert(evalIn('DB.activity.length') === 8, 'activity lost after reset');
});

/* ---------------------------------------------------------------- results */
const failed = results.filter((r) => r.startsWith('  ✗'));
console.log('\nSingle-file runtime smoke test\n' + results.join('\n'));
if (errors.length) console.log('\nUncaught page errors:\n' + errors.map((e) => '  ! ' + e).join('\n'));
console.log('\n' + (results.length - failed.length) + '/' + results.length + ' passed');
// The app runs a 1s tick for cooldowns, so tear jsdom down explicitly.
window.close();
process.exit(failed.length || errors.length ? 1 : 0);
