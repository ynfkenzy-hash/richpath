import { z } from 'zod';

/* ==========================================================================
 * @richpath/shared — single source of truth for request/response contracts.
 * Frontend and backend both import these; validation rules can never drift.
 * ========================================================================== */

export const LOCALES = [
  'en', 'ru', 'pt', 'es', 'de', 'fr', 'tr', 'ar', 'vi', 'ja',
  'bn', 'hi', 'id', 'ur', 'sw', 'uk', 'fil', 'ms', 'ko', 'fa',
] as const;
export type Locale = (typeof LOCALES)[number];

export const RTL_LOCALES: Locale[] = ['ar', 'ur', 'fa'];

/* ------------------------------------------------------------------ auth -- */

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(72, 'Password must be under 72 characters')
  .regex(/[a-zA-Z]/, 'Password must contain a letter')
  .regex(/[0-9]/, 'Password must contain a number');

export const registerSchema = z.object({
  name: z.string().trim().min(2, 'Name is too short').max(40),
  email: z.string().trim().toLowerCase().email('Enter a valid email'),
  password: passwordSchema,
  /** Bonus/referral code of the person who invited you (optional). */
  referralCode: z.string().trim().max(24).optional().or(z.literal('')),
  locale: z.enum(LOCALES).default('en'),
  acceptTerms: z.literal(true, { errorMap: () => ({ message: 'You must accept the Terms and Privacy Policy' }) }),
});
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email('Enter a valid email'),
  password: z.string().min(1, 'Enter your password'),
});
export type LoginInput = z.infer<typeof loginSchema>;

export interface PublicUser {
  id: string;
  name: string;
  email: string;
  referralCode: string;
  balance: number;          // withdrawable balance, USD
  pendingBalance: number;   // earned but inside review window
  lifetimeEarned: number;
  referralCount: number;
  verified: boolean;
  createdAt: string;
}

/* --------------------------------------------------------------- economy -- */

export type TaskCategory = 'game' | 'survey' | 'app' | 'signup';
export type TaskCompletionStatus = 'started' | 'pending_review' | 'credited' | 'rejected';

export interface Task {
  id: string;
  title: string;
  description: string;
  category: TaskCategory;
  reward: number;
  estimatedMinutes: number;
  /** Provider-side landing/offer URL (mock provider generates these too). */
  offerUrl: string;
  logoColor: string;
  /** Completion state for the requesting user, if any. */
  completion?: {
    status: TaskCompletionStatus;
    startedAt: string;
    creditedAt: string | null;
  } | null;
  cooldownEndsAt?: string | null;
}

export interface VideoTask {
  id: string;
  /** YouTube video id (11 chars). The client embeds this directly. */
  youtubeId: string;
  title: string;
  author?: string;
  reward: number;
  durationSeconds: number;
  /** Playback seconds the client must reach before a claim is accepted. */
  requiredSeconds: number;
  watched: boolean;
}

export interface DailyState {
  claimedToday: boolean;
  streak: number;
  todayReward: number;
  /** Position in the 7-day cycle that the next claim lands on. */
  cycleDay: number;
  nextClaimAt: string | null;
  /** Milestones: consecutive days → bonus */
  schedule: { day: number; reward: number }[];
}

export type WithdrawalStatus = 'pending' | 'under_review' | 'payout_sent' | 'failed';

export interface Withdrawal {
  id: string;
  amount: number;
  method: 'bank' | 'usdt';
  status: WithdrawalStatus;
  createdAt: string;
  updatedAt: string;
  /** Masked destination, e.g. ****1234 — never return the full value. */
  destinationMasked: string;
  note?: string;
}

export interface PaymentMethod {
  method: 'bank' | 'usdt';
  accountName: string;
  /** For bank: masked account no. For USDT: masked wallet address. */
  destinationMasked: string;
  updatedAt: string;
}

export interface LedgerEntry {
  id: string;
  type: 'task' | 'video' | 'daily' | 'referral' | 'welcome' | 'withdrawal';
  amount: number; // positive = credit, negative = debit
  balanceAfter: number;
  description: string;
  createdAt: string;
}

/* --------------------------------------------------------------- misc ---- */

export interface ActivityEvent {
  id: string;
  maskedName: string;   // "j***n"
  countryCode: string;
  amount: number;
  at: string;
}

export interface ReferralSummary {
  referralCode: string;
  referralCount: number;
  qualifiedCount: number;      // invitees who completed >= 1 task
  totalReferralEarnings: number;
  dailyRewardAvailable: boolean;
  dailyRewardAmount: number;
  nextMilestone: { target: number; reward: number; reached: boolean } | null;
  milestones: { target: number; reward: number; reached: boolean }[];
  referrals: { maskedName: string; joinedAt: string; earned: number }[];
}

export interface ApiError {
  error: { code: string; message: string; details?: Record<string, string[]> };
}

export interface Paged<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
}

/* ----------------------------------------------------- response wrappers -- */

export interface AuthResponse {
  user: PublicUser;
  /** Access token is ALSO set as an httpOnly cookie; returned for non-browser
   *  clients (tests, mobile) that cannot use cookies. */
  token: string;
  /** Progressive delay the UI should apply before showing an offerwall. */
  offerwallReadyInSeconds: number;
}

export interface EligibilityResult {
  eligible: boolean;
  reasons: { code: string; message: string; current?: number; required?: number }[];
  steps: { key: 'tasks' | 'referrals' | 'balance' | 'payment_method' | 'review'; done: boolean; label: string }[];
}
