This folder is the zero-server delivery form of the product:

  standalone/richpath-demo.html   the entire product in ONE file — no server and
                                  no network calls. Open it in a browser or host
                                  it on any static host.

Everything else is the full multi-file build (API + web + shared), deployable
with Docker or plain Node. Start with DEPLOY.md. No real .env or database is
included; `.env.example` and `.env.production.example` document every setting.
