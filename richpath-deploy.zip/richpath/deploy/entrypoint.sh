#!/bin/sh
# ============================================================================
#  Container entrypoint: migrate, then optionally seed, then start the API.
#  Migrations are idempotent (tracked in a `migrations` table), so running this
#  on every boot is safe and is the intended upgrade path: deploy a new image,
#  restart, and the schema catches up with the code.
# ============================================================================
set -e

echo "[entrypoint] applying migrations to ${DATABASE_FILE:-/data/richpath.db}"
node apps/api/dist/db/migrate.js || {
  echo "[entrypoint] migration step failed — refusing to start against an unknown schema"; exit 1;
}

if [ "${SEED_ON_BOOT}" = "true" ]; then
  echo "[entrypoint] seeding demo content"
  node apps/api/dist/db/seed.js || echo "[entrypoint] seed skipped"
fi

echo "[entrypoint] starting: $*"
exec "$@"
