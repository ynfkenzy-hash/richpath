# Deploying RichPath

Three ways to run this, from simplest to most complete. Pick one.

| Option | What you get | Needs | Time |
| --- | --- | --- | --- |
| **A · Single file** | The full demo product, one HTML file, no server | Any static host (or a USB stick) | 1 minute |
| **B · Docker Compose** | The real stack: API + SQLite + nginx, HTTPS-ready | Docker | ~10 minutes |
| **C · Plain Node** | Same stack without Docker — a VPS, systemd, a VPS + Caddy | Node 20, a server | ~20 minutes |

---

## A · Single file (no server at all)

`standalone/richpath-demo.html` is the entire product — UI, mock backend,
persistence — in one file with **zero network calls**. Upload it anywhere that
serves static files (Netlify, Vercel, S3, GitHub Pages, nginx, a shared host):

```bash
# any static host
scp standalone/richpath-demo.html you@host:/var/www/html/index.html
```

What it does not have: real accounts, real money, real YouTube search (the key
would be public). It is a demonstration and review build. Good for showing the
product; **not** for taking registrations.

---

## B · Docker Compose (recommended)

```bash
cp .env.production.example .env
#  → edit .env: JWT_SECRET, PUBLIC_ORIGIN. Both are required and the API
#    refuses to start in production with the development secret.
docker compose up -d --build
docker compose logs -f api          # migrations run on boot
```

Then open `http://<server>:8080` (or whatever `WEB_PORT` you set).

**What happens on first boot**

1. `deploy/entrypoint.sh` runs migrations against `/data/richpath.db` on the
   named volume. Migrations are tracked and idempotent, so this is also the
   upgrade path: pull a new image, `docker compose up -d`, schema catches up.
2. The API starts and waits on `GET /api/v1/health`.
3. nginx serves the built SPA and proxies `/api/` to the API container.

**Put TLS in front.** The session cookie is marked `Secure` when
`NODE_ENV=production`, so plain HTTP will not hold a login. Caddy is two lines:

```
your-domain.com {
    reverse_proxy 127.0.0.1:8080
}
```

**Back up the volume.** Everything that matters is `/data/richpath.db`:

```bash
docker compose exec api node -e "require('better-sqlite3')('/data/richpath.db').pragma('wal_checkpoint(TRUNCATE)')"
docker run --rm -v richpath-data:/data -v "$PWD:/backup" alpine \
  tar czf /backup/richpath-$(date +%F).tar.gz -C /data .
```

---

## C · Plain Node (no Docker)

```bash
npm ci                                     # installs all workspaces
npm run build                              # shared → api → web
cp .env.production.example apps/api/.env   # fill in JWT_SECRET + PUBLIC_ORIGIN
npm run db:migrate                         # creates/updates the SQLite file
npm run db:seed                            # optional: demo content
NODE_ENV=production node apps/api/dist/server.js
```

Serve `apps/web/dist` with nginx using `deploy/nginx.conf` as the template, and
change the proxy target from `http://api:4000` to `http://127.0.0.1:4000`.

A minimal systemd unit:

```ini
[Unit]
Description=RichPath API
After=network.target

[Service]
WorkingDirectory=/srv/richpath
EnvironmentFile=/srv/richpath/apps/api/.env
ExecStart=/usr/bin/node apps/api/dist/server.js
Restart=always
User=richpath

[Install]
WantedBy=multi-user.target
```

---

## Environment variables that matter in production

| Variable | Why it is not optional |
| --- | --- |
| `JWT_SECRET` | ≥32 chars, random. The API refuses to boot in production with the dev value. Rotating it invalidates every session. |
| `PUBLIC_ORIGIN` / `CORS_ORIGINS` | The browser origin allowed to call the API. Getting it wrong either breaks the app or opens it to any site. |
| `NODE_ENV=production` | Turns on the `Secure` cookie flag and disables `POST /users/me/demo-topup`. |
| `DATABASE_FILE` | Absolute path inside the container (`/data/richpath.db`). Point it at a volume — a container filesystem is not durable. |
| `TRUST_PROXY=1` | Behind nginx/a load balancer, so rate limits and audit rows see real client IPs. Defaults to on in production — turn it **off** only if the API is exposed directly, or clients can spoof `X-Forwarded-For`. |
| `COOKIE_SECURE=1` | Defaults to on in production; without it the session cookie can travel over plain HTTP. |
| `OPERATOR_NOTIFY_ENABLED` + `OPERATOR_NOTIFY_EMAIL` | Optional operator alerts (new signup, lockout, payout request). Events only — never passwords or tokens. Use a role address on your own domain. |

Full list with comments: `.env.production.example` and `apps/api/.env.example`.

---

## Pre-launch checklist

The code is production-shaped, but a rewards platform has obligations beyond
code. Do not take real users until these are true:

- [ ] **Offerwall provider contracted** and postback secret configured — without
      it there is nothing to pay out, and the task centre is demo data.
- [ ] **Terms, Privacy Policy and Cookie notice** drafted by a lawyer for the
      countries you operate in: payouts, personal data, referral programme,
      age gate (18+).
- [ ] **Email verification and password reset** wired (see `docs/06` §6.4) —
      currently missing by design.
- [ ] **Admin review console** for the withdrawal queue; today approvals are
      manual SQL or the demo auto-advance.
- [ ] **Tax and payout-rail compliance** in your jurisdiction (KYC thresholds,
      reporting duties, permitted payout methods).
- [ ] **Rate limits and lockouts reviewed** against your expected traffic.
- [ ] **Backups scheduled and restore-tested** (a backup you have not restored
      is a hope, not a backup).
- [ ] **Analytics, if any**, behind consent — never send emails, referral codes
      or payout destinations to analytics.

## Security notes for whoever runs this

- Passwords are bcrypt hashes; they are **not recoverable by anyone**, including
  operators. Nothing in this codebase forwards a password anywhere, and
  `apps/api/src/integrations/notify.ts` actively refuses payloads that look like
  credentials or payout data. Keep it that way — harvesting login details is
  credential theft, whatever it is called internally.
- Sessions are revocable rows, not just JWTs, so "log out everywhere" works.
- Every balance change goes through one transactional ledger helper; negative
  balances throw rather than silently persisting.
- Provider postbacks are HMAC-verified in constant time and are idempotent.
- Never paste a production `.env` into a support thread, a screenshot, or an
  issue tracker.
