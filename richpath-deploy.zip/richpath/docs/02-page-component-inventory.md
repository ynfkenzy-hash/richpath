# 2. Page & component inventory

Mirrors the reference route map (documented in `01-architecture-analysis.md`) with original
implementation. "Rebuilt" = implemented in this repo.

## 2.1 Route inventory

| Route | Rebuilt | Page file | Guard | Notes |
| --- | --- | --- | --- | --- |
| `/` | ✅ | `pages/LandingPage.tsx` | public | Hero, live ticker, stats, how-it-works, reviews carousel, FAQ accordion, footer |
| `/login` | ✅ | `pages/AuthPage.tsx` | `RedirectIfAuthed` | Sign-in / sign-up tabs, invite code in `?ref=`, field-level validation |
| `/user` | ✅ | `pages/UserPage.tsx` | `RequireAuth` | Balance hero, stat row, next-step card, quick tasks, recent earnings |
| `/task` | ✅ | `pages/TaskCenterPage.tsx` | `RequireAuth` | Category filters, cooldown timers, start → offer → complete flow |
| `/video` | ✅ | `pages/VideoPage.tsx` | `RequireAuth` | Daily cap, bonus unlock, watch timer, per-video once-per-day |
| `/daily` | ✅ | `pages/DailyPage.tsx` | `RequireAuth` | Streak, 7-day schedule, claim, next-claim countdown |
| `/partners` | ✅ | `pages/ReferralPage.tsx` | `RequireAuth` | Invite link/code + copy, masked invitee list, milestone bars, daily claim |
| `/withdraw` | ✅ | `pages/WithdrawPage.tsx` | `RequireAuth` | Eligibility checklist, payout-method modal, amount form, confirm dialog |
| `/record` | ✅ | `pages/RecordsPage.tsx` | `RequireAuth` | Earnings log (paginated) + payment log with statuses |
| `/faq` | ✅ | `pages/FaqPage.tsx` | `RequireAuth` | Original 10-question FAQ |
| `/about` | ✅ | `pages/StaticPages.tsx` | `RequireAuth` | Original copy, clearly labelled demo |
| `/privacy` | ✅ | `pages/StaticPages.tsx` | `RequireAuth` | Describes what this code actually stores; placeholder legal notice |
| `/contact` | ✅ | `pages/StaticPages.tsx` | `RequireAuth` | Support email from env |
| `/offer/:slug` | ✅ | `pages/OfferPage.tsx` | public | **Stand-in for a third-party offer page** — replaces a real offerwall in demo mode |
| `*` | ✅ | `pages/StaticPages.tsx` | public | 404 |

## 2.2 Component inventory

**Layout** (`components/layout/`)
- `Shell.tsx` — top bar (menu / logo / language / balance chip), responsive drawer, bottom tab bar (mobile), safe-area padding
- `LanguageModal.tsx` — 20 locales listed; 7 ship translations, the rest fall back to English and are marked "soon"
- `Logo.tsx` — original SVG mark

**UI kit** (`components/ui/index.tsx`) — no component library dependency
| Component | Used for |
| --- | --- |
| `Button` | 4 variants × 3 sizes, loading + disabled states, focus ring |
| `Field` | label, hint, error, `aria-invalid`, `aria-describedby`, trailing slot |
| `Card` · `Alert` · `Modal` · `EmptyState` · `Skeleton` · `Stat` · `Badge` · `Spinner` | layout & feedback |
| `cx` | class merge helper |

**Feature components**
- `features/auth/AuthProvider.tsx` — session query, login/register/logout mutations, global 401 handling, cache purge on identity change
- `components/guards/RequireAuth.tsx` — `RequireAuth`, `RedirectIfAuthed`
- `TaskCenterPage` → `OfferModal` (engagement countdown + demo offer notice)
- `WithdrawPage` → `PaymentMethodModal` (masked storage warning)

## 2.3 API surface consumed by the UI

| Method | Endpoint | Used by |
| --- | --- | --- |
| GET | `/auth/session` | app boot |
| POST | `/auth/register` · `/auth/login` · `/auth/logout` · `/auth/logout-all` | AuthPage, Shell |
| GET/PATCH | `/users/me` | Shell, UserPage, WithdrawPage |
| POST | `/users/me/password` | (settings flow) |
| GET | `/users/me/ledger` | UserPage, RecordsPage |
| GET | `/tasks` · POST `/tasks/:id/start` · POST `/tasks/:id/complete` | TaskCenterPage |
| GET | `/videos` · POST `/videos/:id/complete` | VideoPage |
| GET | `/daily` · POST `/daily/claim` | DailyPage, Shell badge |
| GET | `/referrals` · POST `/referrals/claim-daily` | ReferralPage |
| GET | `/withdrawals` · `/withdrawals/eligibility` · `/withdrawals/payment-methods` (PUT) · POST `/withdrawals` | WithdrawPage, RecordsPage |
| GET | `/content/stats` · `/content/activity` · `/content/reviews` | LandingPage |
| POST | `/integrations/offerwall/postback` | third-party provider (S2S, not the browser) |

## 2.4 State & data-flow conventions

- **Server state** lives in React Query: `qk.*` key registry in `lib/queryClient.ts`; mutations
  invalidate the specific keys they touch (never a blanket `invalidateQueries()`).
- **Identity changes purge the cache** so two demo accounts can never see each other's data.
- **401 anywhere** flips the session cache and the guard redirects — no half-signed-in UI.
- **Money** is a dollar number at the API boundary and integer cents everywhere internally.
- **Timers** (cooldowns, streaks, video progress) always re-check on the server; the client only
  renders them.

## 2.5 Responsive behaviour

| Breakpoint | Behaviour |
| --- | --- |
| < 640 px (mobile) | Bottom tab bar (Home · Tasks · Invite · Video · Cash), slide-over drawer, single-column cards, bottom-sheet modals, safe-area insets |
| 640–1024 px (tablet) | 2–3 column grids, drawer still available, modals centred |
| ≥ 1024 px (desktop) | Persistent side navigation, 4-column stat row, 3-column card grids, centred max-w-5xl column |
| RTL locales | `dir="rtl"` on `<html>`; logical properties (`ms-*`, `me-*`, `start/end`) throughout so the layout flips without a separate stylesheet |
| A11y | Focus-visible rings, `aria-*` on dialogs/tabs/fields, `prefers-reduced-motion` honoured, semantic landmarks |
