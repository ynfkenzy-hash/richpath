# 5. Project folder structure

```
richpath-rebuild/
├── package.json                     # npm workspaces root; dev/build/test/db scripts
├── .env.example                     # every environment variable, documented
├── .gitignore
├── README.md
├── docs/                            # the analysis + plan deliverables
│   ├── 01-architecture-analysis.md
│   ├── 02-page-component-inventory.md
│   ├── 03-technology-recommendation.md
│   ├── 04-database-api-requirements.md
│   ├── 05-project-structure.md
│   ├── 06-api-requirements.md
│   ├── 07-implementation-plan.md
│   └── 08-compliance-and-ethics.md
│
├── packages/shared/                 # contracts shared by both apps
│   └── src/index.ts                 # Zod schemas + TS types (register/login, Task, Withdrawal, …)
│
├── apps/api/                        # backend: HTTP + business rules + SQL
│   ├── package.json                 # dev / build / test / db:migrate / db:seed / db:reset
│   ├── tsconfig.json
│   ├── data/                        # SQLite file (git-ignored)
│   ├── test/flow.test.ts            # 23 end-to-end API tests
│   └── src/
│       ├── server.ts                # boot: assert config → migrate → listen → background tick
│       ├── app.ts                   # express app factory (testable, no listen)
│       ├── config.ts                # env parsing + validation, typed and frozen
│       ├── routes.ts                # mounts every module under /api/v1
│       ├── db/
│       │   ├── index.ts             # connection, pragmas, tx() helper
│       │   ├── migrate.ts           # forward-only migrations
│       │   ├── seed.ts              # ORIGINAL demo data (tasks, videos, reviews, ticker)
│       │   └── reset.ts             # drop + rebuild
│       ├── lib/
│       │   ├── errors.ts            # AppError + BadRequest/Unauthorized/… helpers
│       │   ├── ledger.ts            # applyLedger(): the ONLY writer of balances
│       │   ├── money.ts             # cents ⇄ dollars at the boundary
│       │   ├── crypto.ts            # ids, bcrypt, tokens, HMAC proof, masking
│       │   ├── time.ts              # SQLite → ISO, "a day" = UTC date
│       │   └── validate.ts          # Zod request middleware
│       ├── middleware/
│       │   ├── auth.ts              # cookie/bearer, session lookup, guards, session issue
│       │   ├── rateLimit.ts         # auth / claim / general buckets
│       │   └── errorHandler.ts      # single JSON error shape, no stack leaks in prod
│       ├── integrations/
│       │   ├── offerwall.ts         # PROVIDER INTERFACE + demo provider + HTTP skeleton
│       │   └── geoip.ts             # VPN/GeoIP integration point
│       └── modules/                 # vertical slices: routes.ts + service.ts each
│           ├── auth/                # register, login, sessions, referral attribution
│           ├── users/               # profile, password, ledger, demo top-up
│           ├── tasks/               # catalogue, start/complete, referrer share, postbacks
│           ├── videos/              # daily list, watch completion, bonus unlock
│           ├── daily/               # streak logic
│           ├── referrals/           # invite summary, milestones, daily claim
│           ├── withdrawals/         # eligibility, payment methods, cash-out, auto-advance
│           └── content/             # public marketing endpoints (flagged isDemo)
│
└── apps/web/                        # frontend: SPA
    ├── package.json · tsconfig.json · vite.config.ts · tailwind.config.js · postcss.config.js
    ├── index.html
    └── src/
        ├── main.tsx                 # providers: QueryClient → Router → Auth
        ├── App.tsx                  # route table
        ├── vite-env.d.ts            # typed import.meta.env
        ├── styles/index.css         # Tailwind layers, base a11y rules, reduced-motion
        ├── i18n/
        │   ├── index.ts             # i18next setup + RTL direction helper
        │   └── locales/*.json       # en, es, fr, de, pt, ru, ar
        ├── lib/
        │   ├── api.ts               # axios instance, ApiRequestError, 401 hook
        │   ├── queryClient.ts       # query defaults + key registry (qk)
        │   └── format.ts            # money/time/countdown/masking formatters
        ├── features/auth/AuthProvider.tsx
        ├── components/
        │   ├── guards/RequireAuth.tsx
        │   ├── layout/{Shell,Logo,LanguageModal}.tsx
        │   └── ui/index.tsx         # Button, Field, Card, Modal, Alert, … (~200 lines)
        └── pages/                   # one file per route
            LandingPage · AuthPage · UserPage · TaskCenterPage · VideoPage · DailyPage
            ReferralPage · WithdrawPage · RecordsPage · FaqPage · OfferPage · StaticPages
```

## Conventions

| Rule | Rationale |
| --- | --- |
| One folder per feature on the server (`routes.ts` + `service.ts` + SQL) | A new feature touches one directory |
| `applyLedger()` is the only thing that changes a balance | Money bugs are impossible to hide |
| Shared Zod schemas in `packages/shared` | Client and server can't disagree about validity |
| `qk.*` query keys, never inline key arrays | Invalidation can't silently miss a cache entry |
| Env vars only via `config.ts` (API) / `import.meta.env` (web) | No magic strings, one place to audit |
| Timestamps stored UTC, converted at the edge | Streaks and cooldowns stay honest across timezones |
| Demo data flagged in the payload (`isDemo`) | The UI cannot accidentally pass sample data off as real |
