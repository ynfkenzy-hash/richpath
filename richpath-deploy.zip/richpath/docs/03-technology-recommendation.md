# 3. Technology recommendation

## 3.1 Recommended stack (and what shipped in this repo)

| Layer | Choice | Why | Shipped |
| --- | --- | --- | --- |
| Frontend | **React 18 + TypeScript + Vite** | Same family as the reference (React + Vite + React Router + i18next + axios + utility CSS), so the UX patterns translate 1:1; Vite gives fast HMR and a small, chunked production build | ✅ |
| Routing | React Router 6 with lazy routes | Mirrors the reference's route table; code-splitting per route | ✅ (routes are eager for clarity; splitting is configured in `vite.config.ts`) |
| Server state | TanStack Query | Caching, retries, invalidation per feature; avoids hand-rolled loading flags | ✅ |
| Forms | React Hook Form + Zod schemas from `packages/shared` | One schema, validated in the browser *and* on the server | ✅ |
| Styling | Tailwind CSS with design tokens | Matches the utility-CSS approach observed; dark surface + single accent is easy to theme | ✅ |
| i18n | i18next + browser detector, RTL support | The reference ships 20 locales; the architecture supports that without a rewrite | ✅ (7 locales, swappable) |
| API | **Node 20 + Express 4 + TypeScript**, vertical slices | Small surface, easy to read; each module owns routes + service + SQL | ✅ |
| Validation | Zod at every trust boundary | Reject before touching the DB | ✅ |
| DB | **SQLite (better-sqlite3)** for the demo, **PostgreSQL** for production | Zero-setup locally, real SQL semantics, trivially portable | ✅ SQLite |
| Auth | JWT in an **httpOnly cookie** + server-side session rows | Cookie = no token in JS (XSS-resistant); session rows = revocable logout, device list, logout-all | ✅ |
| Passwords | bcrypt (cost 10 dev / 12 prod) | Industry default, tunable cost | ✅ |
| Rate limiting | `express-rate-limit` per bucket (auth / claims / general) | Cheap first line of defence | ✅ |
| Security headers | Helmet + strict CORS allow-list | Replaces the reference's wildcard CORS | ✅ |
| Tests | `node:test` + real HTTP against a temp DB | Fast, no extra runner, exercises the true stack | ✅ 23 tests |
| Money | integer cents end-to-end | No float drift in a ledger | ✅ |

## 3.2 Production upgrades to plan for

| Area | Demo build | Production target |
| --- | --- | --- |
| Database | SQLite file | PostgreSQL + migrations (Prisma/Drizzle/Kysely), read replica for reporting |
| Cache/queues | in-process `setInterval` tick | Redis (cooldowns, rate limits) + BullMQ/SQS worker for postbacks and payouts |
| Sessions | DB rows + JWT | Same, plus short-lived access token + rotating refresh token if a mobile client appears |
| Payouts | auto-approve after N seconds | PSP/bank API (e.g. Wise, Stripe Connect, local rails) or a crypto payout service, with maker-checker approval and immutable audit trail |
| Offerwall | offline mock provider | One or more networks (OfferToro, AdGate, Ayet, CPX, BitLabs, Pollfish…) behind the `OfferwallProvider` interface |
| Fraud | IP cap + proof tokens | Device fingerprinting, GeoIP/VPN scoring, offer-provider postback reconciliation, duplicate-payout-destination graph, manual review queue |
| Observability | console logs | Structured logs (pino), error tracking (Sentry), metrics + alerts on payout/rejection ratios |
| Email | none | Transactional provider (Postmark/SES) for verification, payout notices, security alerts |
| Deployment | two dev servers | Containerised API + static SPA on a CDN, IaC, staging environment, backups + restore drills |
| Compliance | placeholder legal pages | Real Terms, Reward & Payout Policy, Privacy Policy, cookie consent, tax reporting (1099/W-8BEN or local equivalent), age gate |

## 3.3 Deliberate technology decisions

- **No component library.** The reference pulls in Vant markers; bundling a UI kit you don't theme
  fully is how dark-mode and RTL bugs appear. The UI kit here is ~200 lines and fully themeable.
- **No ORM in the demo.** Explicit SQL in each service keeps the queries auditable — you can see
  exactly what touches money. Add an ORM when the team grows, not before.
- **Shared Zod contracts.** `packages/shared` is imported by both apps, so a validation rule can
  never drift between client and server. This is the single highest-value structural choice here.
- **Vertical slices, not horizontal layers.** `modules/tasks/` contains its router, service and SQL.
  A new feature is a new folder, not edits across six shared directories.
