# 8. Compliance, ethics and what this rebuild refuses to copy

The reference site is a rewards platform, and that genre sits on top of real legal exposure. This
document is not legal advice — it is a list of the specific decisions made in this codebase and why,
so you can take them to a lawyer with context.

## 8.1 The recruitment-gated payout (not reproduced)

The reference's own copy states:

> "you also need to invite 10 friends to register before you can withdraw cash"

Making the ability to withdraw depend on recruiting new participants is the structural definition of
a pyramid scheme. It is prohibited in the EU (Unfair Commercial Practices Directive; most member
states also criminalise pyramid promotion), the UK (CPRs 2008), Brazil, Canada and most US states,
and it is the exact mechanism that turns a rewards site into a fraud case. Under EU/UK rules the
*invitation* alone can be actionable even before anyone is actually denied payment.

**What this rebuild does instead**

- The cash-out checklist contains only things the user does for themselves: finish 3 tasks, add a
  payout method, reach the published minimum balance, pass review.
- Invite milestones exist as an optional daily bonus (`modules/referrals/service.ts`).
- Two places in the UI state plainly that recruitment is never required to be paid
  (`ReferralPage`, `FaqPage`).
- The 10 % share of invitee earnings is capped to *earned* income, not to recruitment; nobody earns
  anything merely for signing people up beyond the single signup reward.

## 8.2 The embedded personal-data list (not reproduced)

The public bundle contains a large array of `{first_name, last_name, country}` records — including
some that are obviously real people's names and email addresses — used to populate the
"someone just got paid" ticker and testimonials. Two problems:

1. **Data protection.** Shipping such a list to every visitor's browser is a disclosure of personal
   data to the world, regardless of where the list came from.
2. **Deception.** Lookalike testimonials and a fabricated payout feed are unverifiable claims.

**What this rebuild does instead**

- `activity_feed` and `content_reviews` are seeded with **original, generated** entries, flagged
  `is_demo = 1` at the row level.
- The public API returns `isDemo: true` and the UI renders a visible "Sample data" badge plus an
  amber notice that invented payout totals and testimonials are deceptive advertising.
- Any name that reaches a public endpoint is masked at the source (`maskName()`), so no future
  endpoint can leak an unmasked name by accident.

## 8.3 Marketing claims

"100K+ users", "$1M+ paid", "1.5M+ downloads, 150k+ reviews, 4.8 stars" are unverifiable from
outside and, if false, are deceptive advertising in every jurisdiction you can operate in.
`/content/stats` in this build reads **real counts from the database** and attaches
`note: "Sample figures for the demo build…"`. Before launch: publish audited numbers, link to the
source, or remove the claims.

## 8.4 FAQ content standard

The reference site's FAQ is reassurance copy: it answers objections without committing to anything. This
rebuild keeps the questions that actually decide trust and answers them with checkable facts.

| Rule | Why it matters |
| --- | --- |
| No income promises — no "guaranteed", no headline "earn $X/day", amounts stated per activity only | Earnings claims are the single biggest consumer-protection exposure for a rewards site, and in several jurisdictions an unfair commercial practice |
| Every stated rule must match what the API enforces (`apps/api/src/config.ts`): credited-task minimum, published payout minimum, `VIDEO_MIN_PLAYBACK_SECONDS`, cooldowns and daily caps | An FAQ that misstates the rules is either a misrepresentation or a support-ticket factory |
| Say what happens to *existing* balances when an offer is reversed ("a reversed offer never removes money already earned") | This is the fear the FAQ exists to answer, and honesty here is cheaper than defending a clawback later |
| State plainly that recruiting is never required, and name pyramid schemes | Distances the product from the pattern the reference site flirts with |
| Say what the platform will never ask for (password, one-time code, "release fee") | The most effective anti-fraud message a rewards site can publish |
| Label demonstration or sample data wherever a figure could be read as a real result | Keeps the marketing surface honest while the product is a rebuild |

Content lives in `apps/web/src/content/faq.ts` (11 answers; the first six appear on the landing page) and in
the single-file demo's `FAQ` array, which reads its numbers from `CFG` so they cannot drift from the code.

## 8.5 Consumer-protection exposure to plan for

| Requirement | Why it applies | Where it's handled here |
| --- | --- | --- |
| Publish the conditions of payout *before* the user earns | Hidden conditions = unfair commercial practice | `/withdrawals/eligibility` returns the checklist to the UI *and* a test asserts it is enforced |
| No dark patterns on balance | "Withdraw all balance" and similar forced flows are high-complaint patterns | Amount is user-entered with a confirm dialog |
| Real support channel and response times | Complaint handling is a legal obligation in the EU/UK | Contact page is a documented integration point for a ticketing tool |
| Clear statement of who pays the reward | Users must know they are completing third-party advertising offers, and that their data goes to that advertiser | The task modal and privacy page both say it; the offerwall is an explicit integration point rather than an invisible tag |
| Age gate | Under-18s cannot lawfully agree to most offerwall terms; teen-focused copy in this genre is a red flag | **Not implemented** — flagged as a launch blocker |
| Tax reporting | Payouts above thresholds are reportable income in most countries | **Not implemented** — provider/KYC decision |

## 8.6 Security commitments already in the code

- Passwords hashed with bcrypt; never logged, never returned.
- Session JWT in an httpOnly cookie backed by revocable server-side session rows; logout-all;
  password change invalidates every other session.
- Login lockout, per-bucket rate limits, generic auth errors, timing-equalised failures.
- Strict CORS allow-list (the reference sends `Access-Control-Allow-Origin: *`), helmet headers,
  64 kb body cap.
- Zod validation on every route including the provider postback; signature comparison in constant
  time; unconfigured providers fail closed.
- Payout destinations stored masked + hashed; duplicate destinations blocked across accounts.
- Money can only move through `applyLedger()`; a negative balance throws.
- Account takeover protections still missing: **email verification, password reset, 2FA** — listed
  as the next security increment.

## 8.7 On the name and branding

"RichPath" is used in this rebuild **only as a placeholder** so the demo matches the reference's
route labels while you review it. The reference site's name, logo, imagery and copy are its own.
Before any public deployment: rename the product (set `VITE_APP_NAME`, replace `Logo.tsx`, change
the i18n strings), replace all demo content, and confirm you have rights to every asset you ship.

## 8.8 What was deliberately *not* done while analysing

- No account creation, no login, no authenticated endpoint access.
- No attempt to bypass authentication, paywalls, CAPTCHAs, geoblocks, rate limits or any other
  access control.
- No scraping of user data, no crawling of private areas, no interaction with the production API.
- No copying of source code, assets, images, review text, user records or backend implementation —
  only genre-level patterns, reimplemented with original code, data and design.
- No reproduction of the embedded personal-data list, the fabricated payout feed, or the
  recruitment-gated withdrawal rule.
