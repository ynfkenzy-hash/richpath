# 7. Implementation plan (and what was actually built)

## Phase 0 — Reconnaissance ✅
Fetched the public page and bundles, mapped routes, features, copy rules, third-party calls and API
shape. Documented in `01-architecture-analysis.md`. No authenticated area, private endpoint or
protected resource was touched.

## Phase 1 — Foundations ✅
- npm workspaces monorepo (`apps/api`, `apps/web`, `packages/shared`).
- `.env.example` covering every variable; `config.ts` validates and freezes them at boot
  (refuses to start in production with the dev JWT secret).
- Forward-only migrations + seed + reset scripts.
- **Test:** `npm run db:migrate` on an empty directory, then boot the API.

## Phase 2 — Auth & security ✅
- Register / login / logout / logout-all / session probe; bcrypt; JWT in an httpOnly cookie backed
  by revocable session rows; lockout after 10 failed logins; timing-equalised failures; generic
  error messages; per-IP registration cap; Zod validation shared with the client.
- Referral attribution at signup (inviter credited inside the same transaction).
- **Tests:** register, duplicate email (409), weak password (400 + field details), unauthenticated
  access (401), wrong password leaking nothing, logout invalidating the session.

## Phase 3 — Account & ledger ✅
- `applyLedger()` as the single balance writer (credits, debits, pending, lifetime, `balance_after`).
- Ledger endpoint (paginated) + dashboard balance/pending/lifetime.
- Password change revokes all other sessions.
- **Test:** ledger contains welcome, task, video, daily and withdrawal rows.

## Phase 4 — Task Center ✅
- Catalogue with categories and per-user completion state; start → signed proof token → complete.
- Server-side minimum engagement window; 24 h per-task cooldown; single-credit guard; referrer
  income share (10 %) written in the same transaction.
- Provider postback handler: HMAC-verified, idempotent, fails closed.
- **Tests:** credit, double-credit blocked (409), forged proof rejected, postback without a secret
  rejected, 3-task review threshold enforced.

## Phase 5 — Video Center ✅ (now playing real YouTube)
- Daily list with cap, per-video once-per-day, watch-time requirement, extra videos unlocked after
  3 credited tasks.
- **Real YouTube embeds** through the official IFrame Player API on `youtube-nocookie.com`; watch
  time counted only while the player reports `PLAYING`; embed refusals (101/150), removals (100/2)
  and unplayable videos (5) surfaced in plain language and dropped from rotation; 6–10 s loader
  timeout falls back to the offline simulated player.
- Catalogue seeded with **11 real, oEmbed-verified embeddable videos** (Blender, Kurzgesagt, TED,
  melodysheep, Mark Rober) with true durations; live streams excluded.
- Optional server-side discovery: `GET /videos/discover` → Data API v3 search with
  `videoEmbeddable=true`, failing closed with 503 when `YOUTUBE_API_KEY` is absent.
- Rule: a view counts at `min(VIDEO_MIN_PLAYBACK_SECONDS, 90% of duration)` seconds, re-checked
  server-side before the ledger row is written.
- **Tests:** credit, under-watch rejection (400 + `requiredSeconds`), duplicate-view block, seeded
  ids/durations valid, discovery fails closed without a key.

## Phase 6 — Daily & referrals ✅
- 7-day streak schedule with DB-enforced one-claim-per-day and streak reset logic.
- Invite link/code, masked invitee list, milestone progress, daily referral claim.
- **Tests:** single daily claim; invitee registration pays and links the inviter; invitee names are
  masked in the API response.

## Phase 7 — Cash-out ✅
- Eligibility checklist (tasks, payment method, balance, review), payout-method capture stored
  **masked + hashed only**, duplicate-destination block, funds held on request, payment log with
  statuses, demo auto-advance.
- **Tests:** blocked until eligible, implausible destination rejected, raw destination never
  returned, balance deducted, second concurrent request blocked.

## Phase 8 — Frontend ✅
- Route table matching the reference, shell with drawer + bottom tabs + balance chip, 11 pages,
  UI kit, accessible dialogs and fields, responsive at mobile/tablet/desktop, RTL, reduced motion.
- React Query with a key registry; identity changes purge cached data; global 401 handling.
- i18n with 7 locales and a 20-locale switcher.

## Phase 9 — Verification ✅
| Check | Result |
| --- | --- |
| `npm --workspace apps/api run test` | **23/23 passing** |
| `npm --workspace apps/web run build` | builds, split into 4 chunks |
| `npm --workspace apps/api run build` | type-clean |
| Live end-to-end over the dev proxy | register → session cookie → task start → early completion **rejected** (`not_enough_time`) → completion after 20 s **credited** ($1.20, balance $1.50) |

## Phase 10 — Not built (deliberately, or next)

| Item | Status | Notes |
| --- | --- | --- |
| Admin/review console | Not built | The reference has no public admin UI; a review queue is the next thing a real operator needs |
| Real offerwall connection | Integration point only | Needs your network credentials — see `06-api-requirements.md` |
| Real payout rail | Not built | Needs a PSP account, KYB and a payout policy |
| Email verification & password reset | Not built | Token table + provider required |
| 2FA | Not built | TOTP over the existing session model is the natural next step |
| Account deletion | Not built | Retention rules make this a policy decision first |
| Consent/CMP banner | Not built | No third-party scripts to consent to *yet*; add one with the first tag |
| Terms/Privacy | Placeholder | Have a lawyer draft the real versions |

### Suggested next three increments
1. **Admin review console** (list pending completions/withdrawals, approve/reject with reason, audit
   trail) — unlocks operating the product.
2. **Provider integration + reconciliation job** — unlocks real rewards.
3. **Email verification, password reset, TOTP 2FA** — unlocks account recovery and reduces the
   account-takeover cash-out risk.
