# 6. External API requirements & integration points

The reference product is not self-contained: its rewards come from advertising offers supplied by a
third party. This document says exactly what that integration needs, and how to switch it on.

## 6.1 Offerwall / survey network (the one that matters)

**Why it's required.** Task rewards are paid by advertisers, not by the platform. Without an
offerwall network the Task Center has nothing real to show. It is also the single largest dependency
for payouts, so it deserves a signed, idempotent, reconcilable integration.

**Interface implemented** (`apps/api/src/integrations/offerwall.ts`):

```ts
interface OfferwallProvider {
  name: string;
  listOffers(ctx: OfferContext): Offer[];                   // { providerOfferId, title, rewardCents, url, … }
  buildStartUrl?(offer, ctx): string;                        // SSO/tracking link (HMAC user id)
  verifyPostback(headers, body): PostbackPayload | null;     // MUST fail closed
}
```

Two implementations ship:

| Provider | When | Behaviour |
| --- | --- | --- |
| `DemoProvider` (default) | `OFFERWALL_ENABLED=false` | Offers come from the local `tasks` table; the "provider page" is `/offer/:slug` inside this app; testable offline |
| `HttpProvider` | `OFFERWALL_ENABLED=true` | Refuses to run unless `OFFERWALL_APP_ID` + `OFFERWALL_SECRET_KEY` are set; contains the exact call sites to implement |

**Everything you need from a network before you can integrate it**

1. **Publisher/SDK credentials** — app id + secret key (server-side only, never in the bundle).
2. **Offer feed endpoint** (or a hosted iframe/SDK). If it's an iframe you cannot read rewards from
   the DOM — the reward must arrive by postback. Amounts are *always* taken from the postback.
3. **Postback contract** — the URL you register, the parameter names, and the signature scheme
   (usually an HMAC or a shared-secret hash over `user_id + txn_id`).
4. **Test/sandbox mode** — a way to generate a fake conversion so you can verify the money path
   before going live.
5. **Reversal contract** — how chargebacks are signalled, and the window in which they can occur
   (this is why rewards should start as *pending*, not immediately withdrawable).
6. **Geographic availability rules** — offers are country-restricted; a mismatched GeoIP means
   "no offers available" and support tickets.
7. **Commercial terms** — revenue share, payout threshold, payment schedule, holdback period and
   fraud-chargeback policy. A 10 % member share only works if your share is comfortably above it.

**Provider postback endpoint already built**

```
POST /api/v1/integrations/offerwall/postback
X-Signature: <hex HMAC-SHA256 over completion_id + provider_txn_id>
body: { user_id, offer_id, completion_id, amount, provider_txn_id, status: "credited" | "reversed" }
```

Properties: signature compared in constant time · idempotent (returning `credited` twice is a no-op)
· unknown completion ids are rejected · amount comes from the provider · `reversed` marks the
completion rejected · a test asserts it returns 400 when no secret is configured.

**To enable a real network:** set `OFFERWALL_ENABLED=true`, fill the credentials in `.env`, implement
`HttpProvider.listOffers()`/`buildStartUrl()` against your network's docs, register the postback URL,
then generate a sandbox conversion and confirm the ledger row.

## 6.2 Payout / payment rails

Currently: `WITHDRAWAL_AUTO_APPROVE_SECONDS` advances a request `pending → under_review → payout_sent`
so the full lifecycle is demonstrable without moving money. Production needs a real rail.

| Rail | What you need | Considerations |
| --- | --- | --- |
| Bank transfer (fiat) | PSP account with payout API (Wise, Stripe Connect, Payoneer, or local rails) | KYB on your company, KYC/AML on payees above thresholds, sanctions screening, account-name matching, return handling |
| Crypto (USDT) | Custodial payout service or your own hot wallet + treasury controls | Wallet address validation per chain, network-fee policy, hot-wallet key management, chain-analytics screening |
| Gift cards / vouchers | Provider API | Lower compliance load, but lower perceived value |

Whatever you pick, the code needs: a payout adapter behind an interface, maker-checker approval,
an idempotency key per request, webhook handling for success/failure, and a reconciliation job that
compares your `withdrawals` table against the provider's report daily.

## 6.2b YouTube (the video category)

The video category plays **real YouTube videos**. Three things are needed to do that properly.

**1 · Embedding, not scraping.** The player is the official IFrame Player API pointed at
`youtube-nocookie.com` (no tracking cookie until playback begins). You never download or re-host
video — embedding is what the YouTube Terms permit, and it keeps the creator's view counted.

**2 · Embeddability is a real constraint.** A large share of videos have embedding disabled by their
owner. Those fail at play time with error **101/150**; **100/2** mean the video is gone; **5** means
it cannot play embedded. The app surfaces each in plain language and **drops the video from
rotation** instead of leaving a dead player and a dead reward button.

- Before adding videos to your catalogue, check them with the public oEmbed endpoint:
  `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=<id>&format=json` —
  **HTTP 200 = public and embeddable**, 401 = embedding disabled. No API key needed. The seeded
  catalogue in `apps/api/src/db/seed.ts` was verified this way.
- **Exclude live streams.** A live stream has no duration and never emits `ENDED`, so it can never
  satisfy a completion rule.
- Thumbnails come from `https://i.ytimg.com/vi/<id>/mqdefault.jpg`.

**3 · Discovery uses the Data API v3 (server-side).** `apps/api/src/integrations/youtube.ts`
implements `discoverVideos(query)`:

```
GET https://www.googleapis.com/youtube/v3/search
      ?part=snippet&type=video&videoEmbeddable=true&videoSyndicated=true
      &safeSearch=strict&maxResults=25&q=<query>&key=<YOUTUBE_API_KEY>
GET https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=<ids>&key=<key>
```

- `videoEmbeddable=true` + `videoSyndicated=true` are the filters that stop you filling the list with
  videos that cannot pay out; `safeSearch=strict` is brand safety.
- The second call supplies real durations (`contentDetails.duration`, ISO-8601) which the watch-time
  rule needs. Entries without a duration (live/upcoming) are discarded.
- **Quota:** `search.list` costs **100 units** of the default 10,000/day, `videos.list` costs **1**.
  Discovery is therefore an operator/admin action (exposed here as `GET /videos/discover`, auth +
  rate-limited), never something a page view triggers. Cache results in the `videos` table.
- The route returns **503 `youtube_not_configured`** when `YOUTUBE_API_KEY` is missing, so the
  failure is explicit rather than an empty list.

**Reward integrity.** Watch time is measured from the player's own state changes — a second counts
only while the player reports `PLAYING` — and the client can only claim
`min(VIDEO_MIN_PLAYBACK_SECONDS, 90% of duration)` seconds. The server re-checks that number against
the video's stored duration before writing any ledger row. For anything of real value, corroborate
it with your own player beacon or the offerwall provider's postback rather than trusting the browser.

**Privacy disclosure.** An embed means Google receives a request from your user's browser (IP, user
agent, referrer) before anyone presses play. That belongs in your privacy policy and, in the EU/UK,
behind consent. Videos you own and host yourself avoid the third party entirely.

**Switching sources in the demo build.** `richpath-demo.html` offers four sources from the Video
Center: the built-in verified pool (default), Data API discovery with a key you paste, your own id
list, and a fully offline simulated player. The key there lives in your browser, which is exactly why
the real app proxies the call on the server instead — the demo says so in its own settings panel.

## 6.3 Fraud, GeoIP & VPN detection

`apps/api/src/integrations/geoip.ts` implements `lookupIp(ip) → { countryCode, isVpnOrDatacenter,
riskScore }`. Disabled by default (the demo resolver derives a country deterministically from the
IP so the UI has something to render).

- Recommended: MaxMind GeoLite2/GeoIP2 (offline, no per-request fee) or a fraud provider
  (IPQualityScore, SEON) if you need proxy/Tor scoring.
- Use it for: offer eligibility, signup screening, payout risk. Cache aggressively.
- **Fail open** on provider outages with a neutral profile, or a third-party incident becomes your
  outage — but log it so fraud review can see the gap.

## 6.4 Messaging (recommended, not required)

| Purpose | Suggested |
| --- | --- |
| Email verification, payout notices, security alerts | Postmark / Amazon SES / Resend |
| SMS or OTP | Twilio / local aggregator |
| Support inbox | Your existing helpdesk; expose one rate-limited contact form pointing at it. The rebuild ships **`Richard23@gmail.com`** as the shown support address (`VITE_SUPPORT_EMAIL`, default in `apps/web/src/pages/StaticPages.tsx`). Move to `support@<your-domain>` before launch — a personal mailbox has no DMARC/aligned SPF for your brand, cannot be shared with a second agent, and leaks a personal identity into every support thread. |

Never email a payout destination change without a confirmation step in the app — that is the classic
account-takeover cash-out path.

### Operator notifications — and the thing never to build

An operator reasonably wants to know what happens on their platform. The legitimate shape of that is
`apps/api/src/integrations/notify.ts`: a small, off-by-default notifier for **platform events** — new
registration, account lockout, payout requested. It enforces, in code:

- **No credentials, ever.** Passwords are bcrypt hashes from the moment they are stored, so there is
  nothing readable to forward. `assertNoSecrets()` additionally *refuses* any payload carrying a
  password-, token-, OTP- or payout-shaped field, and the test suite proves it fails closed.
- **No tokens or session data**, because a notification carrying a session token turns an inbox into an
  account-takeover kit.
- **Minimal PII**: a masked address (`r***@example.com`) plus an internal user id is enough to act on.
- **A role address on your own domain**, listed in the privacy notice as a recipient of platform data.

What must never be built, under any name — "login notifications", "credential logging", "redirect
logins to my inbox" — is a mechanism that captures or forwards user login details anywhere. That is
credential harvesting: unlawful in essentially every jurisdiction, a data-breach generator, and the
exact behaviour a phishing kit exhibits. A platform that asks for it cannot pass a security review,
cannot hold a payment-processor account, and will lose every user it lies to. If you need to know who
signed in, you read your own audit table (`audit(id, 'login', ip)`) as the operator — you do not
intercept credentials on the way in.

## 6.5 Analytics (optional — with consent)

The reference site loads a third-party analytics tag with no visible consent layer. If you add
analytics: gate it behind consent, prefer a privacy-first tool (Plausible/Umami — self-hosted if
possible), and keep the events coarse (page views, funnel steps). Never send emails, referral codes
or payout destinations to analytics — that turns a marketing tool into a personal-data processor.

## 6.6 What this rebuild will *not* integrate

- No scraping of the reference site's data or endpoints.
- No bypass of any CAPTCHA, paywall, geoblock, rate limit or authentication mechanism.
- No embedded third-party personal-data lists (the reference ships one for its ticker; see
  `docs/08-compliance-and-ethics.md`).
