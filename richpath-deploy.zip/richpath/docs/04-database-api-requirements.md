# 4. Database & API requirements

## 4.1 Data model (implemented in `apps/api/src/db/migrate.ts`)

All money is **integer cents**. All timestamps are SQLite `datetime('now')` (UTC); the API converts
them to ISO-8601 on the way out (`lib/time.ts`).

```
users ─────────────┬──< sessions                (revocable logins, logout-all)
  id (uuid)        ├──< task_completions ──> tasks      (offer catalogue)
  name             ├──< video_views ──────> videos      (daily video rewards)
  email (unique)   ├──< daily_claims                    (streak + per-day unique)
  password_hash    ├──< ledger                          (every balance mutation)
  referral_code    ├──< referral_rewards                (signup / share / milestone)
  referred_by ─────┘  ├──< payment_methods              (masked destination + hash)
  balance_cents       └──< withdrawals                  (pending → under_review → payout_sent)
  pending_cents
  lifetime_cents       activity_feed    (public, masked, is_demo flag)
  locale, verified     content_reviews  (public, masked, is_demo flag)
  status, failed_logins, locked_until, reg_ip
  created_at, updated_at
```

Key constraints and why they exist:

| Constraint | Purpose |
| --- | --- |
| `users.email UNIQUE` | one account per address |
| `users.referral_code UNIQUE` | shareable invite codes are collision-checked on insert |
| `task_completions UNIQUE(user_id, task_id, provider_txn_id)` | idempotent provider postbacks |
| `daily_claims UNIQUE(user_id, claim_date)` | one streak claim per UTC day, enforced by the DB (not by UI state) |
| `referral_rewards UNIQUE(referrer_id, referee_id, kind)` | a signup reward is paid exactly once |
| `payment_methods UNIQUE(user_id, method)` | one bank + one wallet per account |
| `payment_methods.destination_hash` (unique across accounts, checked in `upsertPaymentMethod`) | shared payout destinations are the #1 multi-accounting signal |
| `ledger.balance_after_cents` | every row carries the balance *after* it, so history always reconciles |
| `schema_migrations` | forward-only migrations, re-runnable at boot |

Retention/PII notes: `reg_ip` and `audit_log` exist for abuse review and should be pruned on a
schedule; raw payout destinations are **never** stored (masked + SHA-256 hash only).

## 4.2 API surface

Base path `/api/v1`. All responses are JSON; errors are
`{ "error": { "code", "message", "details?" } }` where `details` is a field→messages map that the UI
renders inline.

### Auth
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| POST | `/auth/register` | — | Zod-validated; bcrypt hash computed before the transaction; welcome bonus + referral reward inside one transaction |
| POST | `/auth/login` | — | generic errors, timing-equalised, lockout after 10 failures |
| POST | `/auth/logout` | session | revokes this session, clears the cookie |
| POST | `/auth/logout-all` | session | revokes every session for the account |
| GET | `/auth/session` | optional | cheap boot probe |

### User
`GET /users/me` (releases matured pending rewards first) · `PATCH /users/me` (name, locale) ·
`POST /users/me/password` (verifies current password, revokes other sessions) ·
`GET /users/me/ledger?page&pageSize` (paginated).

### Tasks
`GET /tasks` → catalogue + per-user completion state + cooldown end ·
`POST /tasks/:id/start` → creates a `started` completion, returns a **server-signed proof token**
and the offer URL ·
`POST /tasks/:id/complete` → verifies token ownership, elapsed time ≥ `TASK_MIN_ENGAGEMENT_SECONDS`,
single credit, referrer share (10 %).

### Videos
`GET /videos` → today's list, watched flags, limit (base + bonus if ≥ 3 credited tasks) ·
`POST /videos/:id/complete { secondsWatched }` → requires ≥ 90 % of the declared duration, one view
per video per day, daily cap enforced.

### Daily
`GET /daily` → streak, cycle day, today's reward, schedule ·
`POST /daily/claim` → one per UTC day, streak continues only if the last claim was yesterday.

### Referrals
`GET /referrals` → code, masked invitee list, qualified count, milestone progress, daily-claim
availability · `POST /referrals/claim-daily`.

### Withdrawals
`GET /withdrawals` · `GET /withdrawals/eligibility` · `GET|PUT /withdrawals/payment-methods` ·
`POST /withdrawals` (validates eligibility, holds funds, writes the ledger row).

### Content (public)
`GET /content/stats` · `GET /content/activity?limit` · `GET /content/reviews` — all return
`isDemo: true` and masked names.

### Integration (provider → server)
`POST /integrations/offerwall/postback` — HMAC-signature verified, idempotent, rejects unknown
completions, and **fails closed** when no provider secret is configured (covered by a test).

### Health
`GET /health` — pings the database; point your load balancer here.

## 4.3 Trust boundaries — where validation happens

| Boundary | Rule |
| --- | --- |
| Browser → API | Zod schema per route (`lib/validate.ts`); unknown fields dropped; body capped at 64 kb |
| Client-reported numbers | Never trusted for money or time: reward comes from the DB row, elapsed time from the server clock, watch time re-checked against the video's duration |
| Provider → API | HMAC signature compared in constant time; amount taken from the provider; completion must already exist |
| API → DB | Every balance change goes through `applyLedger()` inside a transaction; negative balances throw |
| API → browser | Only masked payout destinations, masked invitee names, no password hashes, no session tokens for other users |

## 4.4 External services this product class needs

| Service | Required? | This build | Notes |
| --- | --- | --- | --- |
| **Offerwall / survey network** | Yes, to be real | `integrations/offerwall.ts` — `DemoProvider` (offline) + documented `HttpProvider` | See `docs/06-api-requirements.md` |
| Payment rail (bank/PSP) or crypto payout | Yes, to pay out | Auto-approve demo tick | Payout APIs require KYB/KYC and typically a manual approval step |
| GeoIP / VPN detection | Recommended | `integrations/geoip.ts`, off by default | Offer advertisers reject VPN traffic; detecting it protects the payout rate |
| Email/SMS | Recommended | Not wired | Verification, payout notices, security alerts |
| Analytics | Optional | None | Add only with consent; the reference ships a third-party tag with no visible consent layer |
| Object storage/CDN | Optional | None | Only if you serve user-uploaded assets |
