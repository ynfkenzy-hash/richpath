# 1. Website architecture analysis

**Target:** `https://ricijnth-cduscd.xyz/user` (branded *RichPath* on the page itself)
**Analysed:** 27 Sep 2026, from publicly served assets only.
**Method:** fetched `/user`, `/`, and a handful of guessed routes; downloaded the publicly served
`/assets/index-*.js`, `/assets/index-*.css` and `/assets/polyfills-*.js` bundles; inspected their
strings and module structure. No accounts, private endpoints, authenticated areas, or protected
resources were accessed; no authentication, paywall or rate limit was bypassed.

> **Scope note.** The site has **not** been shown to be yours. Everything below is analysis of
> publicly delivered client code and visible behaviour, and the rebuild in this repo reproduces
> *genre-level patterns* (rewards platform: tasks, videos, referrals, cash-out) with 100 % original
> code, copy, data and design. Nothing was copied: no source code, images, logos, review text,
> user records, or API implementation. Where the reference site does something that is illegal,
> deceptive or unsafe, this rebuild deliberately does it differently and says so (see
> `docs/08-compliance-and-ethics.md`).

---

## 1.1 What the site actually is

A **single-page application (SPA) for a rewards/offerwall platform**. Users complete advertising
offers ("tasks"), watch short videos, keep a daily streak and invite friends; earned "balance" is
later cashed out via bank transfer or USDT.

Detected facts from the served files:

| Observation | Evidence in the public bundle/HTML |
| --- | --- |
| SPA, client-side routed | One `index.html` shell + hashed `/assets/index-*.js`; every guessed path returns the same 12,758-byte document |
| Built with **Vite** | `type="module"` entry, `index-legacy-*.js` + `polyfills-legacy-*.js` = `@vitejs/plugin-legacy`, `__vite__mapDeps` helper, lazily imported route chunks (`UserPage-*.js`, `WithdrawPage-*.js`, `PartnerPage-*.js`, `DailyPage-*.js`, `WithdrawRecord-*.js`, `PayLog-*.js`, `InviteModel-*.js`, `EarnTable-*.js`, `PrivacyPage-*.js`) |
| **React** (react-dom runtime strings, `jsx` calls) | `react`, `Minified React error` UMD strings |
| Routing via React Router | route table: `[{path:"/",...},{path:"/user",title:"RichPath"},{path:"/withdraw",title:"Cash out"},{path:"/partners",title:"Referral"},{path:"/login",title:"Login"},{path:"/task"},{path:"/daily"},{path:"/video"},{path:"/record"},{path:"/about"},{path:"/contact"},{path:"/privacy"},{path:"*"}]` |
| **i18next** localisation, 20 locales | i18next strings + a language modal listing English, Русский, Português, Español, Deutsch, Français, Türkçe, العربية, Tiếng Việt, 日本語, বাংলা, हिंदी, Indonesia, اردو, Swahili, Українська, Filipino, Bahasa Melayu, 한국어, فارسی |
| **axios** HTTP client | `axios` + `baseURL` config |
| Utility-CSS styling | Tailwind-style class strings (`flex justify-between items-center`, arbitrary values like `z-[51]`, `text-[#0A0A0A]`) |
| Component library in places | `vant` markers (mobile-first Vue/Vant-style toasts/dialogs) |
| Hard-coded production API base | `https://comeontasktogether.top/api/v1/` in the client bundle |
| Client-visible API surface | `/user/getuser`, `/user/detail`, `/user/ntglogin`, `/user/ntgregister`, `/user/changlang`, `/user/onlinelog` |
| Telegram login | `https://t.me/...` login link ("ntg" = Telegram-style auth) |
| YouTube embeds for video rewards | `https://www.youtube.com/iframe_api` |
| Cloudflare in front | `server: cloudflare`, `cf-ray`, `cf-cache-status`, Rocket Loader script, `speculation-rules` |
| Third-party analytics | `https://log.plausible.space/js/script.js` |
| External image CDN | `https://cloud.imgs-cdn.com/rp/...` (bank logos, "proof of payment" screenshots, avatars) |
| Open CORS on the API host | `access-control-allow-origin: *` on the document response |

## 1.2 Route map (as declared by the client)

| Route | Title (from route table) | Purpose inferred from UI |
| --- | --- | --- |
| `/` | (landing) | Marketing page: hero, stats, payout ticker, "proof of payment" gallery, testimonials, FAQ |
| `/login` | Login | Sign in / sign up, invite-code entry, Telegram login |
| `/user` | RichPath | Signed-in home: balance chip, quick task list, daily status |
| `/task` | — | Task Center: offer list (games/surveys/apps), rewards, 24 h cooldown |
| `/video` | — | Video Center: per-view rewards, daily cap, bonus unlock |
| `/daily` | — | Daily check-in / streak rewards |
| `/partners` | Referral | Invite link/code, referral list, daily referral rewards, milestones |
| `/withdraw` | Cash out | Eligibility checklist, payment-method setup, request cash-out |
| `/record` | — | Payment log + earnings history with statuses |
| `/about`, `/contact`, `/privacy` | — | Static content pages |
| `*` | — | Catch-all |

## 1.3 Visible behaviour and business rules

Extracted from user-facing strings in the bundle (these are the *rules the UI states*):

- **Tasks**: "The same task can only be done once in 24 hours"; "The task is not completed. You
  need to register or use it for at least 3 minutes." → per-task daily cooldown + minimum
  engagement time before a completion counts.
- **Videos**: "Watch video and earn XXX per video"; "Unlock video missions after completing 3
  tasks"; "Complete 3 tasks to permanently unlock 3 extra video tasks per day"; "Already watched
  this video." → daily cap, per-video once-per-day, bonus unlocks tied to task count.
- **Daily**: streak-based claim with an escalating multi-day schedule.
- **Referrals**: "Invite your friends and earn XXX per referral"; "If the user you invite earns
  money, you will also receive 10 % of that amount as a reward"; "Daily referral rewards … After
  reaching the goal, you can claim the referral reward every day"; input strings show a **10 %
  commission on invitee income** and a **signup bonus**.
- **Withdrawal gates** (the parts this rebuild does *not* copy): "you also need to invite 10
  friends to register before you can withdraw cash"; "Minimum balance required to cash out is
  XXX"; "Please complete at least 3 tasks, otherwise it will affect the withdrawal review
  result"; "After the withdrawal application is successfully submitted, our staff will complete
  the verification within 15 working days"; "You will withdraw all your balance".
- **Payment log statuses**: Under verification → Pending payment → Paid, plus "Withdrawal failed".
- **Payment methods**: "bank card number, USDT wallet address, etc."
- **Trust signals on the landing page**: "100K+ Users", "$1M+ Paid", "Trusted by Brands",
  "1.5M+ downloads, 150k+ reviews, 4.8 stars", a live "New payment sent!" ticker with masked
  usernames, a "Proof Of Payment" image gallery and six 5-star testimonials.

## 1.4 Likely backend architecture (inferred, not observed)

The client talks to a REST API under `/api/v1/` on a separate host, with cookie/bearer auth and a
Telegram login variant. A conventional pairing for this product shape:

```
Cloudflare (CDN/WAF, Rocket Loader)
        │
        ▼
Static SPA hosting (S3/CloudFront or nginx)  ──serves──►  index.html + hashed assets
        │
        ▼  /api/v1/*
Application API (Node/Laravel/Go — not observable from outside)
        │
        ├── MySQL/Postgres: users, sessions, tasks, completions, videos, video_views,
        │                   daily_claims, referrals, ledger, payment_methods, withdrawals
        ├── Redis: sessions, rate limits, leaderboards, cooldowns
        └── Queue/worker: offerwall postbacks, fraud review, payout batching
        │
        ▼
Third-party: offerwall/survey networks (offer feed + S2S postback),
             payment rails (bank/PSP, USDT), GeoIP/VPN detection,
             email/SMS, analytics
```

Nothing in the client bundle reveals the server implementation, and none of it was probed.

## 1.5 Component inventory implied by the route table

Shell: top bar (menu, logo, language selector, balance chip) · slide-in side navigation grouped as
*Home/Invite*, *Task Center/Video/Daily*, *Cash/Payment/FAQ* · bottom tab bar on mobile ·
`InviteModel` (invite modal) · `EarnTable` (earnings table) · `PayLog` (payment log) ·
toast/dialog feedback · FAQ accordion · testimonial carousel · payout ticker · image gallery ·
language modal with 20 locales.

## 1.6 Problems found in the reference (and what this rebuild does instead)

| # | Finding | Why it matters | What this rebuild does |
| --- | --- | --- | --- |
| 1 | **First cash-out is conditional on recruiting 10 people** | Making payout depend on recruitment is the defining structure of a pyramid/Ponzi scheme and is unlawful consumer practice in the EU/UK/BR and many US states | Payout checklist contains only self-completable steps; invite milestones are an *optional bonus*, and the UI says so explicitly |
| 2 | **The bundle ships a large embedded list of real-looking people** (first names, surnames, emails, country codes — hundreds of records used to populate the "someone just got paid" ticker) | Shipping a scraped personal-data list to every visitor's browser is a GDPR/CCPA problem regardless of consent theory | The ticker reads masked, generated entries flagged `isDemo: true`; the API masks every name it returns |
| 3 | **"Proof of payment" images + "$1M+ paid", "100K+ users", "4.8 ★ / 150k reviews"** | Unverifiable marketing claims = deceptive advertising exposure (FTC/ASA/CONAR equivalents) | Demo figures are labelled "sample data" in the UI and API; the docs tell you to publish audited numbers only |
| 4 | **Hard-coded production API base URL in the client** | Cannot promote between environments; leaks infrastructure coupling | `VITE_API_BASE_URL` env var, same-origin `/api/v1` proxy |
| 5 | **`Access-Control-Allow-Origin: *` on the API** | With cookie auth, wildcard CORS is a misconfiguration risk | Strict origin allow-list from `CORS_ORIGINS`, credentials explicitly enabled |
| 6 | **No visible consent/cookie layer** despite analytics + an external image CDN | ePrivacy/GDPR consent obligations | No third-party scripts at all; the privacy page documents exactly what is stored |
| 7 | **Rewards depend on an undisclosed third-party offerwall** | Users can't tell who receives their data | The provider call is an explicit, documented integration point with a working offline mock |
| 8 | Balance is presented as cash while completions are advertiser-gated | Payout disputes are the dominant complaint pattern for this product class | Hold-and-release accounting with a visible ledger, review statuses and published minimums |

Full detail in `docs/08-compliance-and-ethics.md`.
