# RichPath (rebuild)

An **original, clean-room reimplementation** of the user experience of a rewards-platform website:
Task Center, Video Center (real YouTube playback, embeddable-verified catalogue, offline fallback), daily streaks, referrals, a cash-out checklist and a transaction log.

> **Not affiliated with, endorsed by, or connected to any third-party rewards site.** No source code,
> assets, copy, user records or backend implementation were copied. Demo data is labelled as such.
> No money moves in this build.

**Start here:** [`docs/01-architecture-analysis.md`](docs/01-architecture-analysis.md) (analysis of
the reference site) → [`docs/07-implementation-plan.md`](docs/07-implementation-plan.md) (what was
built, phase by phase) → [`docs/08-compliance-and-ethics.md`](docs/08-compliance-and-ethics.md)
(what this rebuild deliberately does differently, and why).

---

## Quick start

```bash
# 1. install (npm workspaces — one install for api + web + shared)
npm install

# 2. configure
cp .env.example apps/api/.env      # the API reads apps/api/.env
cp .env.example .env               # optional: web vars for the root scripts

# 3. database: migrate + seed demo content
npm run db:migrate
npm run db:seed

# 4. run both servers (API :4000, web :5173)
npm run dev
```

Open <http://localhost:5173>, create an account, and work through the flow. The web dev server
proxies `/api` to the API, so cookies stay first-party and there is no CORS in development.

### Try the whole product in 2 minutes

1. **Sign up** on `/login` — you get a welcome bonus and a referral code.
2. **Task Center** → start "Dragon Merge Saga". The demo offer modal counts down; the API also
   enforces the window server-side, so completing early is rejected (try it).
3. **Video Center** → **real YouTube videos** through the official IFrame Player API
   (`youtube-nocookie.com`). A view counts once you have actually played for
   `min(VIDEO_MIN_PLAYBACK_SECONDS, 90% of the video's length)` seconds — the server re-checks that
   figure before paying. Videos whose owner forbids embedding (player error 101/150) are reported in
   plain language and dropped from rotation; if the player cannot load at all, the page offers a
   simulated fallback so the flow stays testable offline. 10/day, +3 unlocked after 3 credited tasks.
   The catalogue ships with 11 embeddable-verified videos, and `GET /videos/discover` adds
   server-side YouTube Data API v3 discovery when `YOUTUBE_API_KEY` is set (503 without it).
4. **Daily** → claim the streak bonus.
5. **Invite** → copy your link, open it in a private window, sign up, and watch the signup reward
   land on the first account.
6. **Cash out** → the checklist shows what's left. Use *demo top-up* (dev only) to shortcut the
   balance step, add a payout method, request a cash-out and watch the status advance in
   **Records → Payment log**.

### Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | API (`:4000`) + web (`:5173`) together |
| `npm test` | 23 end-to-end API tests (isolated temp DB, fast rules) |
| `npm run db:migrate` / `db:seed` | apply migrations / load original demo content |
| `npm run db:reset` | drop the SQLite file and rebuild it with seed data |
| `npm run build` | typecheck + build shared, API and web |

### The one-file build

`../richpath-demo.html` is the whole product condensed into a single HTML file with a
browser-local mock backend — no server, no network, works in a sandboxed preview. It ships the
condensed brief on its own **Build notes** page. Smoke-test it with:

```bash
npm i -D jsdom && node tools/smoke-singlefile.mjs     # 52 checks: every view + every money rule
```

## Architecture at a glance

```
apps/web  (React 18 · Vite · TS · Tailwind · TanStack Query · i18next)
    │  relative /api/v1 calls (proxied in dev) — httpOnly session cookie
    ▼
apps/api  (Express · TS · Zod · better-sqlite3)
    ├── modules/*        vertical slices: routes + service + SQL
    ├── lib/ledger.ts    the ONLY writer of user balances (integer cents)
    ├── middleware/*     auth, rate limits, error shape
    └── integrations/    offerwall + GeoIP integration points (mock by default)
    │
    ▼
packages/shared  Zod schemas + types imported by BOTH apps
```

| Document | Contents |
| --- | --- |
| [01 Architecture analysis](docs/01-architecture-analysis.md) | What the reference site is, how it's built, its routes, rules and problems |
| [02 Page & component inventory](docs/02-page-component-inventory.md) | Every route, component and API call, plus responsive/a11y behaviour |
| [03 Technology recommendation](docs/03-technology-recommendation.md) | Stack choices, rationale, production upgrades |
| [04 Database & API requirements](docs/04-database-api-requirements.md) | Schema, constraints, endpoint list, trust boundaries |
| [05 Project structure](docs/05-project-structure.md) | Annotated folder tree and conventions |
| [06 API requirements](docs/06-api-requirements.md) | Offerwall, YouTube (embeds + Data API v3), payout rails, GeoIP, messaging — what you need and why |
| [07 Implementation plan](docs/07-implementation-plan.md) | The 10 phases, what shipped, what's next |
| [08 Compliance & ethics](docs/08-compliance-and-ethics.md) | Pyramid-scheme rules, personal data, deceptive marketing, security posture |

## Security notes

- bcrypt passwords; JWT in an **httpOnly** cookie backed by **revocable session rows**.
- Login lockout, per-bucket rate limits, generic auth errors, timing-equalised failures.
- Strict CORS allow-list, helmet headers, 64 kb body cap, Zod validation everywhere.
- Provider postbacks are HMAC-verified in constant time, idempotent and fail closed.
- Payout destinations are stored **masked + hashed only**; duplicate destinations are blocked.
- Every balance change goes through one transactional helper; negative balances throw.
- **Missing, and required before going live:** email verification, password reset, 2FA, an age gate,
  real Terms/Privacy drafts, and an admin review console.

## Deploying

See [DEPLOY.md](DEPLOY.md). Three paths: the single file (any static host), Docker Compose
(`cp .env.production.example .env && docker compose up -d --build`), or plain Node on a VPS.
A ready-to-ship archive is produced with the layout the deploy docs expect:

```bash
zip -qr richpath-deploy.zip richpath        # source + deploy/ + prebuilt dist + standalone/
```

## Environment variables

See [`.env.example`](.env.example) — every variable is documented there. The API refuses to start
in production with the development `JWT_SECRET`, and demo-only endpoints
(`POST /users/me/demo-topup`) are hard-disabled when `NODE_ENV=production`.

Support contact: the Contact page, footer and FAQ show the address in `VITE_SUPPORT_EMAIL`
(default `Richard23@gmail.com`, set in `.env.example`). Change the variable, not the code — and use an
address on your own domain before launch.

Two variables are about the video category: `VIDEO_MIN_PLAYBACK_SECONDS` (the watch-time rule) and
`YOUTUBE_API_KEY` (server-side Data API discovery — leave it empty and `GET /videos/discover`
returns 503 `youtube_not_configured` instead of silently doing nothing).

## Legal

Placeholder legal pages are included and are **not legal advice**. Rewards programmes that gate
payouts on recruiting participants are pyramid schemes in most jurisdictions — this build does not
do that, and `docs/08-compliance-and-ethics.md` explains exactly which reference behaviours were
intentionally *not* reproduced. The product name, logo and content here are placeholders: replace
them before any public deployment.
